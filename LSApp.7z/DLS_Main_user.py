'''
Graphic User Interface for Analysis of Dynamic Light Scattering Data

A series of data files can be loaded, visualized and fitted by different algorithms:
    Single Decay
    Two Decays
    Three Decays
    CONTIN Analysis

The first three options fit a series of exponential decays to the correlation function and display the resulting fit.
A calculation of all relevant information is done automatically and can be displayed in a separate window.
The CONTIN Analysis uses an inverse Laplace transform to calculate the size distribution directly from the measured data.
The size distributions are also displayed in a separate window.

To manipulate the graphic interface and customize the plots, a configuration file named 'config.txt' is provided.

-------------------------------------------------------------------------------------------------------------------------------
Copyright: Felix Lauterbach
University of Hamburg
felix.lauterbach@chemie.uni-hamburg.de
-------------------------------------------------------------------------------------------------------------------------------

This software is a beta version.
'''

# import of all relevant libraries as well as GUI files (baseclasses) and supporting files
import sys
import os
import re
from GUI import DLS_Fit_Init_baseclass
from GUI import DLS_Main_baseclass
from GUI import DLS_Results_baseclass
from GUI import DLS_CONTIN_baseclass
import matplotlib.pyplot as plt
import numpy as np
import scipy.constants as constants
import math
import matplotlib.patches as patches
from CONTIN.CONTINWrapper import runCONTINfit
from math import pi
from scipy import integrate
from scipy.optimize import curve_fit
from math import sin, pi
from math import log10, floor
from datetime import datetime
from matplotlib.figure import Figure
from matplotlib.backends.qt_compat import QtCore, QtWidgets, is_pyqt5
from matplotlib.backends.backend_qt5agg import (FigureCanvas, NavigationToolbar2QT as NavigationToolbar)
from matplotlib.widgets import MultiCursor
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import QCoreApplication, Qt
from PyQt5.QtWidgets import QMainWindow, QApplication, QWidget, QDialog, QSizePolicy, QMessageBox, QFileDialog, QShortcut
from PyQt5.QtWidgets import*
from PyQt5.QtGui import QKeySequence
from PyQt5.uic import loadUi

# Assigning the main variables that are imported from the config.txt file
variables = {}

def value_type(value):
    if value[0] == "'":
        return value[1:-1]
    elif value[0] == '(':
        params = value[1:-1].split(',')
        lst = []
        for i in params:
            if '/' in i:
                arr = i.split('/')
                lst.append(float(arr[0]) / float(arr[1]))
            else:    
                lst.append(float(i))
        return tuple(lst)
    elif value == 'None':
        return None
    else:
        return float(value)


with open('config.txt', 'r') as f:
    for line in f:
        if line[0] != '#' and line != '\n':
            name, value, _ = re.split('=|\n', line)
            variables[name] = value_type(value)

default_directory = variables['default_directory']
default_filter = variables['default_filter']
default_save_filter = variables['default_save_filter']

plot_main_color = variables['plot_main_color']
plot_main_marker = variables['plot_main_marker']
plot_main_linestyle = variables['plot_main_linestyle']
plot_main_linewidth = variables['plot_main_linewidth']
plot_main_markersize = variables['plot_main_markersize']
plot_main_fillstyle = variables['plot_main_fillstyle']
plot_main_markeredgewidth = variables['plot_main_markeredgewidth']
plot_main_alpha = variables['plot_main_alpha']
plot_main2_color = variables['plot_main2_color']
plot_main2_marker = variables['plot_main2_marker']
plot_main2_linestyle = variables['plot_main2_linestyle']
plot_main2_linewidth = variables['plot_main2_linewidth']
plot_main2_markersize = variables['plot_main2_markersize']
plot_main2_fillstyle = variables['plot_main2_fillstyle']
plot_main2_markeredgewidth = variables['plot_main2_markeredgewidth']
plot_main2_alpha = variables['plot_main2_alpha']
plot_1_xlim = variables['plot_1_xlim']
plot_1_ylim = variables['plot_1_ylim']
plot_2_xlim = variables['plot_2_xlim']
plot_2_ylim = variables['plot_2_ylim']
plot_main_fontsize = variables['plot_main_fontsize']

plot_init_color = variables['plot_init_color']
plot_init_linestyle = variables['plot_init_linestyle']
plot_init_linewidth = variables['plot_init_linewidth']

plot_cont_color = variables['plot_cont_color']
plot_base_color = variables['plot_base_color']
plot_limits_color = variables['plot_limits_color']

plot_res_color = variables['plot_res_color']
plot_res_linestyle = variables['plot_res_linestyle']
plot_res_linewidth = variables['plot_res_linewidth']
plot_res_alpha = variables['plot_res_alpha']

plot_conc_fontsize_main = variables['plot_conc_fontsize_main']
plot_conc_color1 = variables['plot_conc_color1']
plot_conc_color2 = variables['plot_conc_color2']
plot_conc_color3 = variables['plot_conc_color3']
plot_conc_color4 = variables['plot_conc_color4']
plot_conc_marker = variables['plot_conc_marker']
plot_conc_linestyle = variables['plot_conc_linestyle']
plot_conc_markersize = variables['plot_conc_markersize']
plot_conc_fillstyle = variables['plot_conc_fillstyle']
plot_conc_markeredgewidth = variables['plot_conc_markeredgewidth']
plot_conc_fontsize_sides = variables['plot_conc_fontsize_sides']
plot_conc_alpha_R = variables['plot_conc_alpha_R']
plot_conc_alpha_G = variables['plot_conc_alpha_G']

plot_c_fontsize_main = variables['plot_c_fontsize_main']
plot_c_fontsize_sides = variables['plot_c_fontsize_sides']
plot_c_color1 = variables['plot_c_color1']
plot_c_color2 = variables['plot_c_color2']
plot_c_color3 = variables['plot_c_color3']
plot_c_color4 = variables['plot_c_color4']
plot_c_marker = variables['plot_c_marker']
plot_c_linestyle = variables['plot_c_linestyle']
plot_c_markersize = variables['plot_c_markersize']
plot_c_fillstyle = variables['plot_c_fillstyle']
plot_c_markeredgewidth = variables['plot_c_markeredgewidth']
plot_c_xlim = variables['plot_c_xlim']
plot_c_alpha = variables['plot_c_alpha']


g1_from = variables['g1_from']
g1_to = variables['g1_to']
contrast_x_from = variables['contrast_x_from']
contrast_x_to = variables['contrast_x_to']
contrast_y_from = variables['contrast_y_from']
contrast_y_to = variables['contrast_y_to']
baseline_x_from = variables['baseline_x_from']
baseline_x_to = variables['baseline_x_to']
baseline_y_from = variables['baseline_y_from']
baseline_y_to = variables['baseline_y_to']

gamma_a = variables['gamma_a']
gamma_b = variables['gamma_b']
gamma_c = variables['gamma_c']

fraction_a = variables['fraction_a']
fraction_b = variables['fraction_b']
fraction_c = variables['fraction_c']

tau_a_from = variables['tau_a_from']
tau_a_to = variables['tau_a_to']
tau_b_from = variables['tau_b_from']
tau_b_to = variables['tau_b_to']
tau_c_from = variables['tau_c_from']
tau_c_to = variables['tau_c_to']
fraction_b_from = variables['fraction_b_from']
fraction_b_to = variables['fraction_b_to']
fraction_c_from = variables['fraction_c_from']
fraction_c_to = variables['fraction_c_to']

fit_type = variables['fit_type']

num_data_points = variables['num_data_points']

contin_parameters = [['LAST', '', 1.0],
                    ['NG', 1, float(num_data_points)],
                    ['GMNMX', 1, float(1 / g1_to)],
                    ['GMNMX', 2, float(1 / g1_from)],
                    ['IWT', '', 2.0],
                    ['NERFIT', '', 0.0],
                    ['NINTT', '', -1.0],
                    ['NLINF', '', 1.0],
                    ['IFORMY', '', '(1E11.4)'],
                    ['IFORMT', '', '(1E11.4)'],
                    ['DOUSNQ', '', 1.0],
                    ['IUSER', 10, 2.0],
                    ['RUSER', 10, -1.0],
                    ['NONNEG', '', 1.0]]
# End of import

class DLS_Main(QtWidgets.QMainWindow):
    '''
    Main window of this program. Import, data visualization, and initialization of all other windows via this GUI.
    The class is a subclass of the DLS_Main_baseclass file where all the buttons, labels, and formats are set up.
    The baseclass should not be modified or at least nothing should be removed there to ensure full functionality.
    '''
    def __init__(self):
        '''
        Connection of all signals and slots
        '''
        super(DLS_Main, self).__init__()
        self.ui = DLS_Main_baseclass.Ui_MainWindow()
        self.ui.setupUi(self)

        self.ui.MplWidget = MplWidget(self.ui.centralwidget)
        self.ui.MplWidget.setObjectName("MplWidget")
        self.ui.horizontalLayout_2.addWidget(self.ui.MplWidget)
        self.ui.actionOpen.triggered.connect(self.file_open)
        self.ui.actionExit.triggered.connect(self.close_application)
        self.ui.actionInitialize_Fit.triggered.connect(self.initialize_fit)
        self.ui.actionFit.triggered.connect(self.fit_data)
        self.ui.actionShow_Result.triggered.connect(self.show_fit_result)
        self.ui.actionView.triggered.connect(self.display_result_window)
        self.ui.importButton.clicked.connect(self.import_data)
        self.ui.minusScan.clicked.connect(self.decrease_scan_number)
        self.ui.plusScan.clicked.connect(self.increase_scan_number)
        self.ui.scanNumber.textChanged.connect(self.update_output)
        self.ui.scanNumber.textChanged.connect(self.graph_update)
        self.ui.scanNumber.textChanged.connect(self.change_slider)
        self.ui.verticalSlider.sliderReleased.connect(self.slider_change)
        self.ui.lastMeasurement.returnPressed.connect(self.import_data)

        # Initialization window already loaded in the background. This is important to allow mutual access between both QMainWindows.
        self.window = QtWidgets.QMainWindow()
        self.other_ui = DLS_Fit_Init()

    def file_open(self):
        # Set the text in both LineEdits according to the file chosen in the QFileDialog. '\' are additionally replaced by '/'. Nothing is loaded.
        path, _ = QFileDialog.getOpenFileName(None, 'Open Measurements', default_directory, default_filter, options=QFileDialog.DontUseNativeDialog)
        if path:
            path = path.replace('\\', '/')
            folder_path = path.rsplit('/', 1)[0]
            file_name = path.rsplit('/', 1)[1]
            self.ui.folderPath.setText(QtCore.QCoreApplication.translate("MainWindow", folder_path))
            self.ui.fileName.setText(QtCore.QCoreApplication.translate("MainWindow", file_name))

    def close_application(self):
        # A QMessageBox pops up when the user tries to close the window via the Exit Shortcut 'Ctrl+Q'.
        choice = QMessageBox.question(None, 'Exit the Application',
                                     "Are you sure you want to quit?", QMessageBox.Yes |
                                     QMessageBox.No, QMessageBox.No)

        if choice == QMessageBox.Yes:
            sys.exit()
        else:
            pass

    def file_format(self, filename):
        # Determines the number if digits of the consecutive numbering of the file names. Returns the number of digits.
        try:
            if int(filename[:-4][-1:]) in [i for i in range(10)]:
                form = 1
                if int(filename[:-4][-2:]) in [i for i in range(100)]:
                    form = 2
                    if int(filename[:-4][-3:]) in [i for i in range(1000)]:
                        form = 3
                        if int(filename[:-4][-4:]) in [i for i in range(10000)]:
                            form = 4
                            return form
        except ValueError:
            return form

    def import_data(self):
        '''
        Action when the Import Button is clicked. All initial data are calculated and written into lists for plotting and later calculations.
        Global variables are used to simplify access to those variables from different windows.
        The labels in the MainWindow are also set to give an overview of relevant parameters to every correlation function displayed.
        '''
        global progress_counter
        global initialization_visible
        global result_visible
        progress_counter = 0
        folder_path = self.ui.folderPath.text()
        file_name = self.ui.fileName.text()
        if folder_path == '' and file_name == '': return
        first_scan = self.ui.firstMeasurement.text()
        last_scan = self.ui.lastMeasurement.text()
        step_size = self.ui.stepSize.text()
        self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", ''))
        initialization_visible = False
        result_visible = False
        try:
            global scan_list
            global file_number_list
            global time_list
            global temp_list
            global wavelength_value
            global angle_list
            global refractive_list
            global visc_list
            global correlation_x_list
            global correlation_y_list
            global q_list
            global intensity_list
            global scan_list_fit
            global corr_error_list
            scan_list, file_number_list, time_list, temp_list, wavelength_value, angle_list, refractive_list, visc_list, correlation_x_list, correlation_y_list, q_list, intensity_list, corr_error_list = self.write_data(folder_path, file_name, first_scan, last_scan, step_size)
            if wavelength_value:
                scan_list_fit = [True for i in range(len(scan_list))]
                for lst in range(len(correlation_y_list)):
                    maximum = max(correlation_y_list[lst])
                    for i in range(len(correlation_y_list[lst])):
                        correlation_y_list[lst][i] = correlation_y_list[lst][i] / maximum
                        if len(corr_error_list[lst]) > 1:
                            corr_error_list[lst][i] = corr_error_list[lst][i] / maximum
                self.ui.scanNumber.setText(QtCore.QCoreApplication.translate("MainWindow", str(scan_list[0])))
                self.ui.progressBar.setProperty('value', 100)
                self.ui.verticalSlider.setMinimum(scan_list[0])
                self.ui.verticalSlider.setMaximum(scan_list[len(scan_list) - 1])
                self.ui.verticalSlider.setTickInterval(1)
                self.ui.verticalSlider.setValue(scan_list[0])
                self.graph_update()
                self.update_output()
                self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Import successful!'))
                
        except FileNotFoundError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'File not found!'))
        except ValueError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Enter valid scan number!1'))
        except TypeError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'File not found!'))

    def update_output(self):
        '''
        Whenever either the + or - buttons are clicked or the vertical slider is dragged, the labels are updated.
        '''
        global actual_scan
        try:
            i = int(self.ui.scanNumber.text())
            actual_scan = int(self.ui.scanNumber.text())
            # The fit initialization window is updated as well
            self.other_ui.update()

            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", ''))
            self.ui.fileNumber.setText(QtCore.QCoreApplication.translate("MainWindow", str(file_number_list[i])))
            self.ui.wavelength.setText(QtCore.QCoreApplication.translate("MainWindow", str(wavelength_value)))
            self.ui.angle.setText(QtCore.QCoreApplication.translate("MainWindow", str(angle_list[i])))
            self.ui.temperature.setText(QtCore.QCoreApplication.translate("MainWindow", str(float(int(temp_list[i] * 100) / 100))))
            self.ui.refractiveIndex.setText(QtCore.QCoreApplication.translate("MainWindow", str(refractive_list[i])))
            self.ui.viscosity.setText(QtCore.QCoreApplication.translate("MainWindow", str(visc_list[i])))
        except ValueError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Enter valid scan number!2'))
        except IndexError:
            if self.ui.scanNumber.text() == '':
                self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", ''))
            else:
                self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Scan number out of range!'))

    def decrease_scan_number(self):
        # Decreases the scan number when the - button is clicked and ensures that the resulting numbers can not become negative.
        try:
            if int(self.ui.scanNumber.text()) > 0:
                self.ui.scanNumber.setText(QtCore.QCoreApplication.translate("Main Window", str(int(self.ui.scanNumber.text()) - 1)))
        except ValueError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Enter valid scan number!3'))

    def increase_scan_number(self):
        # Increases the scan number when the + button is clicked and ensures that the resulting value does not exceed the range of scan numbers available in the parent folder.
        global scan_list
        try:
            if int(self.ui.scanNumber.text()) >= 0 and int(self.ui.scanNumber.text()) < len(scan_list) - 1:
                self.ui.scanNumber.setText(QtCore.QCoreApplication.translate("Main Window", str(int(self.ui.scanNumber.text()) + 1)))
        except ValueError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Enter valid scan number!4'))

    def update_progress_import(self, starting_num, end_num):
        # Updates the progress bar during import.
        try:
            global progress_counter
            first_scan = starting_num
            last_scan = end_num
            progress_counter += 1
            self.ui.progressBar.setProperty('value', progress_counter / (last_scan - first_scan) * 100)
        except ValueError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Enter valid scan number!5'))

    def update_progress_fit(self):
        # Updates the progress bar during the fit procedures.
        try:
            global progress_counter
            fit_number = len(scan_list)
            progress_counter += 1
            self.ui.progressBar.setProperty('value', progress_counter / fit_number * 100)
        except ZeroDivisionError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Import data first!'))

    def slider_change(self):
        # Updates the scan number when the value of the vertical slider changes.
        self.ui.scanNumber.setText(QtCore.QCoreApplication.translate("Main Window", str(self.ui.verticalSlider.value())))

    def change_slider(self):
        # Changes the position of the vertical slider when the scan number is changed.
        try:
            self.ui.verticalSlider.setValue(int(self.ui.scanNumber.text()))
        except ValueError:
            pass
        
    def date_to_date(self, date):
        # Formats the date so that it can be processed and calculated correctly.
        if len(date[0]) < 2:
            date[0] = '0' + date[0]
        if len(date[1]) < 2:
            date[1] = '0' + date[1]
        return date

    def read_datafile(self, file_path):
        '''
        Reads a single datafile and processes all relevant information. The correlation function and standard deviation are read after the signal words.
        This works only for files measured by ALV-systems.
        '''
        correlation_x = []
        correlation_y = []
        corr_error = []
        monitor = 0
        try:
            with open(file_path, 'r') as f:
                start_reading = False
                read_again = False
                for line in f:
                    if not 'Samp' in line:
                        if 'Date' in line:
                            if line[-7:-6] == '/':
                                date = line[-12:-2]
                                for i in range(len(date)):
                                    if date[:1] == '"' or date[:1] == ' ' or date[:1] == '' or date[:1] == '\t':
                                        date = date[1:]
                                date = date.split('/')
                                date = self.date_to_date(date)
                                date = date[1] + '.' + date[0] + '.' + date[2]
                            else:
                                date = line[-12:-2]
                                if date[:1] == '"':
                                    date = date[1:]
                                date = date.split('.')
                                date = self.date_to_date(date)
                                date = date[0] + '.' + date[1] + '.' + date[2]
                        elif 'Time' in line:
                            if line[-3:-2] == 'M':
                                time = line[-13:-4]
                                time = re.split('"|:| ', time)
                                time = [num for num in time if num != '']
                                time = self.date_to_date(time)
                                if line[-4:-2] == 'PM':
                                    if int(time[0]) + 12 > 23:
                                        time[0] = str(int(time[0]) - 12)
                                    time = str(int(time[0]) + 12) + ':' + time[1] + ':' + time[2]
                                else:
                                    time = time[0] + ':' + time[1] + ':' + time[2]
                            else:
                                time = line[-10:-2]
                        elif 'Temperature' in line:
                            temp = float(line[-10:-1]) - 273.15
                        elif len(line) < 2 and start_reading == True:
                            start_reading = False
                        elif 'Wavelength' in line:
                            wavelength = float(line[-10:-1])
                        elif 'Angle' in line:
                            angle = float(line[-10:-1])
                        elif 'Refractive Index' in line:
                            refractive_index = float(line[-8:-1])
                        elif 'Viscosity' in line:
                            viscosity = float(line[-8:-1])
                        elif 'Monitor' in line:
                            monitor = float(line[-12:-1])
                        elif 'MeanCR0' in line:
                            count_rate = float(line[-11:-1]) * 1000

                        if start_reading:
                            if line != '\n':
                                correlation_x.append(float(re.findall(r'\S+', line)[0]) / 1000)
                                correlation_y.append(float(re.findall(r'\S+', line)[1]))
                            else:
                                start_reading = False

                        if read_again:
                            if line != '\n':
                                corr_error.append(float(re.findall(r'\S+', line)[1]))
                            else:
                                read_again = False

                        if '"Correlation"' in line:
                            start_reading = True

                        if '"StandardDeviation"' in line:
                            read_again = True

                # Converts the time into a format that can be used by the function 'write_data' to calculate the time
                datetime_object = datetime.strptime(date + ' ' + time, '%d.%m.%Y %H:%M:%S')

                q = 4 * pi * refractive_index / (wavelength * 1e-9) * math.sin(angle / 180 * pi / 2)
                if monitor != 0:
                    normalized_intensity = count_rate * 1000 / monitor * math.sin(angle / 180 * pi)
                else:
                    normalized_intensity = count_rate * 1000 * math.sin(angle / 180 * pi)

            return datetime_object, temp, wavelength, angle, refractive_index, viscosity, correlation_x, correlation_y, q, normalized_intensity, corr_error

        except FileNotFoundError:
            return False
        except NameError:
            return False

    def write_data(self, data_folder, filename, starting_number=0, end_number=9999, step_size=1):
        '''
        Writes the data of the individual files into lists, converts the time and calculates the measurement error if none is given.
        If no error is written to the measurement file the error is calculated as 2 % of the corresponding value.
        '''
        scan_list = []
        file_number_list = []
        time_list = []
        temp_list = []
        angle_list = []
        refractive_index_list = []
        viscosity_list = []
        correlation_x_list = []
        correlation_y_list = []
        q_list = []
        intensity_list = []
        corr_error_list = []
        time_zero = 0
        if starting_number == '':
            starting_number = 0
        if end_number == '':
            end_number = 9999
        if step_size == '':
            step_size = 1
        file_name_format = self.file_format(filename)
        try:
            for i in range(int((int(end_number) - int(starting_number) + 1) / int(step_size))):
                try:
                    if file_name_format == 4:
                        filename = filename[:-8] + ''.join([str(0) for i in range(4 - len(str(i * int(step_size) + int(starting_number))))]) + str(i * int(step_size) + int(starting_number)) + '.asc'
                    elif file_name_format == 3:
                        filename = filename[:-7] + str(i * int(step_size) + int(starting_number)) + '.asc'
                    elif file_name_format == 2:
                        filename = filename[:-6] + str(i * int(step_size) + int(starting_number)) + '.asc'
                    elif file_name_format == 1:
                        filename = filename[:-5] + str(i * int(step_size) + int(starting_number)) + '.asc'
                    time, temp, wavelength, angle, refractive_index, viscosity, correlation_x, correlation_y, q, normalized_intensity, corr_error = self.read_datafile(data_folder + '/' + filename)
                    scan_list.append(i)
                    file_number_list.append(int(starting_number) + i * int(step_size))
                    if time_zero == 0:
                        time_zero = time
                    time = time - time_zero
                    time = time.total_seconds()
                    time_list.append(time)
                    temp_list.append(temp)
                    angle_list.append(angle)
                    refractive_index_list.append(refractive_index)
                    viscosity_list.append(viscosity)
                    correlation_x_list.append(correlation_x)
                    correlation_y_list.append(correlation_y)
                    q_list.append(q)
                    intensity_list.append(normalized_intensity)
                    if len(corr_error) == 0:
                        corr_error = [i * 0.02 for i in correlation_y]
                    corr_error_list.append(corr_error)

                    self.update_progress_import(int(starting_number), int(end_number))
                except TypeError:
                    break
        except ZeroDivisionError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Invalid step size!'))

        try:
            return scan_list, file_number_list, time_list, temp_list, wavelength, angle_list, refractive_index_list, viscosity_list, correlation_x_list, correlation_y_list, q_list, intensity_list, corr_error_list
        except UnboundLocalError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'File not found!'))

    def graph_update(self):
        # Updates the graph output whenever the scan number changes, either by clicking one of the buttons or changing the slider.
        self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", ''))
        try:
            i = int(self.ui.scanNumber.text())
            self.plot_raw_data(i)
            self.plot_fit_init()
            self.plot_results(i)
            #multi = MultiCursor(self.ui.MplWidget.canvas, (self.ui.MplWidget.canvas.axes, self.ui.MplWidget.canvas.axes2), color='r', lw=1, alpha=0.3)
            self.ui.MplWidget.canvas.draw()
        except (TypeError, ValueError):
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Invalid scan number!'))
        except IndexError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Scan number out of range!'))

    def plot_raw_data(self, i):
        # Adds the raw measurement data to the canvas and sets all relevant options for the axes before it is plotted.
        global correlation_x_list
        global correlation_y_list
        self.ui.MplWidget.canvas.axes.clear()
        self.ui.MplWidget.canvas.axes2.clear()
        self.ui.MplWidget.canvas.axes.plot(correlation_x_list[i], correlation_y_list[i], zorder=1, color=plot_main_color, marker=plot_main_marker, linestyle=plot_main_linestyle, markersize=plot_main_markersize, linewidth=plot_main_linewidth, fillstyle=plot_main_fillstyle, markeredgewidth=plot_main_markeredgewidth)
        self.ui.MplWidget.canvas.axes.fill_between(correlation_x_list[i], np.array(correlation_y_list[i]) + np.array(corr_error_list[i]), np.array(correlation_y_list[i]) - np.array(corr_error_list[i]), alpha=plot_main_alpha, color=plot_main_color)
        self.ui.MplWidget.canvas.axes.set_xscale('log')
        self.ui.MplWidget.canvas.axes.set_xlim(plot_1_xlim)
        self.ui.MplWidget.canvas.axes.set_ylim(plot_1_ylim)
        self.ui.MplWidget.canvas.axes.set_ylabel(r'normalized $g_2$($\tau$)', fontsize=plot_main_fontsize)
        self.ui.MplWidget.canvas.axes2.errorbar(correlation_x_list[i], correlation_y_list[i], corr_error_list[i], zorder=1, color=plot_main2_color, marker=plot_main2_marker, linestyle=plot_main2_linestyle, markersize=plot_main2_markersize, linewidth=plot_main2_linewidth, fillstyle=plot_main2_fillstyle, markeredgewidth=plot_main2_markeredgewidth)
        self.ui.MplWidget.canvas.axes2.set_yscale('log')
        self.ui.MplWidget.canvas.axes2.set_xlim(plot_2_xlim)
        self.ui.MplWidget.canvas.axes2.set_ylim(plot_2_ylim)
        self.ui.MplWidget.canvas.axes2.set_xlabel(r'$Time$ / s', fontsize=plot_main_fontsize)
        self.ui.MplWidget.canvas.axes2.set_ylabel(r'normalized $g_2$($\tau$)', fontsize=plot_main_fontsize)

    def plot_function_line(self, x, y):
        # Adds the lines to the canvas that are given by the fit initialization as soon as the respective window is active.
        self.ui.MplWidget.canvas.axes.plot(x, y, zorder=5, color=plot_init_color, linestyle=plot_init_linestyle, linewidth=plot_init_linewidth)
        self.ui.MplWidget.canvas.axes2.plot(x, y, zorder=5, color=plot_init_color, linestyle=plot_init_linestyle, linewidth=plot_init_linewidth)
        self.ui.MplWidget.canvas.axes.legend([r'norm. $g_2$($\tau$)', 'fit-function'],loc='best')
        self.ui.MplWidget.canvas.axes2.legend([r'norm. $g_2$($\tau$)', 'fit-function'],loc='best')

        # The rectangles are generated that show the fit limits for the contrast, baseline and the general fit.
        # Those rectangles can be dragged individually and also change the values in the fit initialization window on release.
        drs = []
        rect1 = patches.Rectangle(xy=(contrast_x_from, contrast_y_from), width=0.1 * contrast_x_from, height=(contrast_y_to - contrast_y_from), angle=0, color=plot_cont_color, alpha=0.3)
        rect1 = self.ui.MplWidget.canvas.axes.add_patch(rect1)
        self.dr1 = self.DraggableRectangle(rect1)
        self.dr1.connect()
        drs.append(self.dr1)
        rect2 = patches.Rectangle(xy=(contrast_x_to, contrast_y_from), width=0.1 * contrast_x_to, height=(contrast_y_to - contrast_y_from), angle=0, color=plot_cont_color, alpha=0.3)
        rect2 = self.ui.MplWidget.canvas.axes.add_patch(rect2)
        self.dr2 = self.DraggableRectangle(rect2)
        self.dr2.connect()
        drs.append(self.dr2)
        rect3 = patches.Rectangle(xy=(baseline_x_from, baseline_y_from), width=0.1 * baseline_x_from, height=(baseline_y_to - baseline_y_from), angle=0, color=plot_base_color, alpha=0.3)
        rect3 = self.ui.MplWidget.canvas.axes.add_patch(rect3)
        self.dr3 = self.DraggableRectangle(rect3)
        self.dr3.connect()
        drs.append(self.dr3)
        rect4 = patches.Rectangle(xy=(baseline_x_to, baseline_y_from), width=0.1 * baseline_x_to, height=(baseline_y_to - baseline_y_from), angle=0, color=plot_base_color, alpha=0.3)
        rect4 = self.ui.MplWidget.canvas.axes.add_patch(rect4)
        self.dr4 = self.DraggableRectangle(rect4)
        self.dr4.connect()
        drs.append(self.dr4)
        rect5 = patches.Rectangle(xy=(g1_from, 0), width=0.1 * g1_from, height=1, angle=0, color=plot_limits_color, alpha=0.3)
        rect5 = self.ui.MplWidget.canvas.axes.add_patch(rect5)
        self.dr5 = self.DraggableRectangle(rect5)
        self.dr5.connect()
        drs.append(self.dr5)
        rect6 = patches.Rectangle(xy=(g1_to, 0), width=0.1 * g1_to, height=1, angle=0, color=plot_limits_color, alpha=0.3)
        rect6 = self.ui.MplWidget.canvas.axes.add_patch(rect6)
        self.dr6 = self.DraggableRectangle(rect6)
        self.dr6.connect()
        drs.append(self.dr6)


    class DraggableRectangle:
        '''
        This class is used for the rectancles in the MainWindow during fit initialization. They can be dragged and change the values
        in the fit initialization window on release.
        On press it is checked if the cursor is on a rectangle and during motion the actual location is logged. On release the final value is stored and written.
        '''
        def __init__(self, rect):
            self.rect = rect
            self.press = None

        def connect(self):
            'connect to all the events we need'
            self.cidpress = self.rect.figure.canvas.mpl_connect(
                'button_press_event', self.on_press)
            self.cidrelease = self.rect.figure.canvas.mpl_connect(
                'button_release_event', self.on_release)
            self.cidmotion = self.rect.figure.canvas.mpl_connect(
                'motion_notify_event', self.on_motion)

        def on_press(self, event):
            'on button press we will see if the mouse is over us and store some data'
            if event.inaxes != self.rect.axes: return
            contains, attrd = self.rect.contains(event)
            if not contains: return
            x0, y0 = self.rect.xy
            self.press = x0, y0, event.xdata, event.ydata
            global dragged_rect
            if x0 == contrast_x_from and y0 == contrast_y_from:
                dragged_rect = 'contrast_x_from'
            elif x0 == contrast_x_to and y0 == contrast_y_from:
                dragged_rect = 'contrast_x_to'
            elif x0 == baseline_x_from and y0 == baseline_y_from:
                dragged_rect = 'baseline_x_from'
            elif x0 == baseline_x_to and y0 == baseline_y_from:
                dragged_rect = 'baseline_x_to'
            elif x0 == g1_from:
                dragged_rect = 'g1_from'
            elif x0 == g1_to:
                dragged_rect = 'g1_to'

        def on_motion(self, event):
            'on motion we will move the rect if the mouse is over us'
            if self.press is None: return
            if event.inaxes != self.rect.axes: return
            x0, y0, xpress, ypress = self.press
            dx = event.xdata - xpress
            dy = event.ydata - ypress
            self.rect.set_x(x0+dx)
            self.rect.set_y(y0+dy)

            self.rect.set_width((x0 + dx) * 0.1)

            self.rect.figure.canvas.draw()

        def reset_borders(self, lower_x, upper_x, lower_y, upper_y, new_y):
            # Ensures that the new y-values of the draggable rectangles are changed correctly.
            upper_y = upper_y - lower_y + new_y
            lower_y = new_y
            return lower_x, upper_x, lower_y, upper_y

        def on_release(self, event):
            'on release we reset the press data'
            self.press = None
            if event.inaxes != self.rect.axes: return
            contains, attrd = self.rect.contains(event)
            if not contains: return
            
            global dragged_rect
            global contrast_x_from
            global contrast_x_to
            global contrast_y_from
            global contrast_y_to
            global baseline_x_from
            global baseline_x_to
            global baseline_y_from
            global baseline_y_to
            global g1_from
            global g1_to


            x0, y0 = self.rect.xy
            if dragged_rect == 'contrast_x_from':
                contrast_x_from = x0
                contrast_x_from, contrast_x_to, contrast_y_from, contrast_y_to = self.reset_borders(contrast_x_from, contrast_x_to, contrast_y_from, contrast_y_to, y0)
            elif dragged_rect == 'contrast_x_to':
                contrast_x_to = x0
                contrast_x_from, contrast_x_to, contrast_y_from, contrast_y_to = self.reset_borders(contrast_x_from, contrast_x_to, contrast_y_from, contrast_y_to, y0)
            elif dragged_rect == 'baseline_x_from':
                baseline_x_from = x0
                baseline_x_from, baseline_x_to, baseline_y_from, baseline_y_to = self.reset_borders(baseline_x_from, baseline_x_to, baseline_y_from, baseline_y_to, y0)
            elif dragged_rect == 'baseline_x_to':
                baseline_x_to = x0
                baseline_x_from, baseline_x_to, baseline_y_from, baseline_y_to = self.reset_borders(baseline_x_from, baseline_x_to, baseline_y_from, baseline_y_to, y0)
            elif dragged_rect == 'g1_from':
                g1_from = x0
            elif dragged_rect == 'g1_to':
                g1_to = x0

            DLS_Fit_Init.update(window.other_ui)
            self.rect.figure.canvas.draw()
            DLS_Main.graph_update(window)

        def disconnect(self):
            'disconnect all the stored connection ids'
            self.rect.figure.canvas.mpl_disconnect(self.cidpress)
            self.rect.figure.canvas.mpl_disconnect(self.cidrelease)
            self.rect.figure.canvas.mpl_disconnect(self.cidmotion)


    def plot_fit_init(self):
        # Sets the functions for plotting of the lines during fit initialization and calls the function that actually adds the lines to the canvas.
        if initialization_visible:
            if fit_type == '' or fit_type == 'One Decay' or fit_type == 'Contin': 
                tau = np.logspace(-7, 1, num=100)
                g2 = np.exp(-2 * gamma_a * tau)
            elif fit_type == 'Two Decays':
                tau = np.logspace(-7, 1, num=100)
                g2 = (fraction_a * np.exp(-gamma_a * tau) + fraction_b * np.exp(-gamma_b * tau))**2
            elif fit_type == 'Three Decays':
                tau = np.logspace(-7, 1, num=100)
                g2 = (fraction_a * np.exp(-gamma_a * tau) + fraction_b * np.exp(-gamma_b * tau) + fraction_c * np.exp(-gamma_c * tau))**2
            self.plot_function_line(tau, g2)

    def plot_result_line(self, x, y):
        # Adds the lines to the canvas that are given by the fit results.
        self.ui.MplWidget.canvas.axes.plot(x, y, zorder=5, color=plot_res_color, linestyle=plot_res_linestyle, linewidth=plot_res_linewidth)
        self.ui.MplWidget.canvas.axes2.plot(x, y, zorder=5, color=plot_res_color, linestyle=plot_res_linestyle, linewidth=plot_res_linewidth)
        self.ui.MplWidget.canvas.axes.legend([r'norm. $g_2$($\tau$)', 'fit-result'],loc='best')
        self.ui.MplWidget.canvas.axes2.legend([r'norm. $g_2$($\tau$)', 'fit-result'],loc='best')

    def plot_result_fill(self, x, ymax, ymin):
        # Adds the fill_between to the canvas.
        self.ui.MplWidget.canvas.axes.fill_between(x, ymax, ymin, zorder=3, color=plot_res_color, alpha=plot_res_alpha)

    def plot_results(self, i):
        # Defines the functions that are used together with the fit parameters to plot the resulting fits after the fit procedure.
        global fit_results
        global result_visible
        global fit_error
        if fit_type == '' or fit_type == 'Contin':
            return
        if result_visible:
            try:
                if fit_type == 'One Decay':
                    tau = np.logspace(-7, 1, num=100)
                    g2 = fit_results[i][0] + fit_results[i][1] * np.exp(-2 * fit_results[i][2] * tau) * (1 + fit_results[i][3] / 2 * tau**2 - fit_results[i][4] / 6 * tau**3)**2
                    g2_max = (fit_results[i][0] + fit_error[i][0]) + (fit_results[i][1] + fit_error[i][1]) * np.exp(-2 * (fit_results[i][2] + fit_error[i][2]) * tau) * (1 + (fit_results[i][3] + fit_error[i][3]) / 2 * tau**2 - (fit_results[i][4] + fit_error[i][4]) / 6 * tau**3)**2
                    g2_min = (fit_results[i][0] - fit_error[i][0]) + (fit_results[i][1] - fit_error[i][1]) * np.exp(-2 * (fit_results[i][2] - fit_error[i][2]) * tau) * (1 + (fit_results[i][3] - fit_error[i][3]) / 2 * tau**2 - (fit_results[i][4] - fit_error[i][4]) / 6 * tau**3)**2
                elif fit_type == 'Two Decays':
                    tau = np.logspace(-7, 1, num=100)
                    g2 = fit_results[i][0] + fit_results[i][1] * (fit_results[i][2] * np.exp(-fit_results[i][3] * tau) * (1 + fit_results[i][4] / 2 * tau**2 - fit_results[i][5] / 6 * tau**3) + fit_results[i][6] * np.exp(-fit_results[i][7] * tau) * (1 + fit_results[i][8] / 2 * tau**2 - fit_results[i][9] / 6 * tau**3))**2
                    g2_max = (fit_results[i][0] + fit_error[i][0]) + (fit_results[i][1]) * ((fit_results[i][2]) * np.exp(-(fit_results[i][3] + fit_error[i][3]) * tau) * (1 + (fit_results[i][4] + fit_error[i][4]) / 2 * tau**2 - (fit_results[i][5] + fit_error[i][5]) / 6 * tau**3) + (fit_results[i][6]) * np.exp(-(fit_results[i][7] + fit_error[i][7]) * tau) * (1 + (fit_results[i][8] + fit_error[i][8]) / 2 * tau**2 - (fit_results[i][9] + fit_error[i][9]) / 6 * tau**3))**2
                    g2_min = (fit_results[i][0] - fit_error[i][0]) + (fit_results[i][1]) * ((fit_results[i][2]) * np.exp(-(fit_results[i][3] - fit_error[i][3]) * tau) * (1 + (fit_results[i][4] - fit_error[i][4]) / 2 * tau**2 - (fit_results[i][5] - fit_error[i][5]) / 6 * tau**3) + (fit_results[i][6]) * np.exp(-(fit_results[i][7] - fit_error[i][7]) * tau) * (1 + (fit_results[i][8] - fit_error[i][8]) / 2 * tau**2 - (fit_results[i][9] - fit_error[i][9]) / 6 * tau**3))**2
                elif fit_type == 'Three Decays':
                    tau = np.logspace(-7, 1, num=100)
                    g2 = fit_results[i][0] + fit_results[i][1] * (fit_results[i][2] * np.exp(-fit_results[i][3] * tau) * (1 + fit_results[i][4] / 2 * tau**2 - fit_results[i][5] / 6 * tau**3) + fit_results[i][6] * np.exp(-fit_results[i][7] * tau) * (1 + fit_results[i][8] / 2 * tau**2 - fit_results[i][9] / 6 * tau**3) + fit_results[i][10] * np.exp(-fit_results[i][11] * tau) * (1 + fit_results[i][12] / 2 * tau**2 - fit_results[i][13] / 6 * tau**3))**2
                    g2_max = (fit_results[i][0] + fit_error[i][0]) + (fit_results[i][1]) * ((fit_results[i][2]) * np.exp(-(fit_results[i][3] + fit_error[i][3]) * tau) * (1 + (fit_results[i][4] + fit_error[i][4]) / 2 * tau**2 - (fit_results[i][5] + fit_error[i][5]) / 6 * tau**3) + (fit_results[i][6]) * np.exp(-(fit_results[i][7] + fit_error[i][7]) * tau) * (1 + (fit_results[i][8] + fit_error[i][8]) / 2 * tau**2 - (fit_results[i][9] + fit_error[i][9]) / 6 * tau**3) + (fit_results[i][10]) * np.exp(-(fit_results[i][11] + fit_error[i][11]) * tau) * (1 + (fit_results[i][12] + fit_error[i][12]) / 2 * tau**2 - (fit_results[i][13] + fit_error[i][13]) / 6 * tau**3))**2
                    g2_min = (fit_results[i][0] - fit_error[i][0]) + (fit_results[i][1]) * ((fit_results[i][2]) * np.exp(-(fit_results[i][3] - fit_error[i][3]) * tau) * (1 + (fit_results[i][4] - fit_error[i][4]) / 2 * tau**2 - (fit_results[i][5] - fit_error[i][5]) / 6 * tau**3) + (fit_results[i][6]) * np.exp(-(fit_results[i][7] - fit_error[i][7]) * tau) * (1 + (fit_results[i][8] - fit_error[i][8]) / 2 * tau**2 - (fit_results[i][9] - fit_error[i][9]) / 6 * tau**3) + (fit_results[i][10]) * np.exp(-(fit_results[i][11] - fit_error[i][11]) * tau) * (1 + (fit_results[i][12] - fit_error[i][12]) / 2 * tau**2 - (fit_results[i][13] - fit_error[i][13]) / 6 * tau**3))**2
                self.plot_result_line(tau, g2)
                self.plot_result_fill(tau, g2_max, g2_min)
            except (IndexError, TypeError):
                self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Plot not included'))

    def initialize_fit(self):
        # Opens the window for fit initialization either by clicking on it in the menu or pressing the shortcut Ctrl+I.
        global initialization_visible
        global result_visible
        self.other_ui.__init__()
        self.other_ui.show()
        initialization_visible = True
        result_visible = False
        self.graph_update()

    def f_one_decay(self, t, base, beta, gamma, u2, u3):
        # Fit function assuming there is one decay.
        return base + beta * np.exp(-2 * gamma * t) * (1 + u2 / 2 * t**2 - u3 / 6 * t**3)**2

    def f_two_decays(self, t, base, beta, frac_a, gamma_a, u2_a, u3_a, frac_b, gamma_b, u2_b, u3_b):
        # Fit function assuming there are two decays.
        return base + beta * (frac_a * np.exp(-gamma_a * t) * (1 + u2_a / 2 * t**2 - u3_a / 6 * t**3) + frac_b * np.exp(-gamma_b * t) * (1 + u2_b / 2 * t**2 - u3_b / 6 * t**3))**2

    def f_three_decays(self, t, base, beta, frac_a, gamma_a, u2_a, u3_a, frac_b, gamma_b, u2_b, u3_b, frac_c, gamma_c, u2_c, u3_c):
        # Fit function assuming there are three decays.
        return base + beta * (frac_a * np.exp(-gamma_a * t) * (1 + u2_a / 2 * t**2 - u3_a / 6 * t**3) + frac_b * np.exp(-gamma_b * t) * (1 + u2_b / 2 * t**2 - u3_b / 6 * t**3) + frac_c * np.exp(-gamma_c * t) * (1 + u2_c / 2 * t**2 - u3_c / 6 * t**3))**2

    def fit_function(self, function, x, y, error, initial_guesses, lower_bounds, upper_bounds):
        '''
        Performs the actual fit using the scipy package and the scipy.optimize.curve_fit function
        The output of this function is a matrix of optimal parameters for the given fit parameters
        and another matrix from which the errors can be calculated. This is done in 'calculate_results' 
        by the diagonal of the matrix yielding the 'param_error' variable.
        '''
        try:
            optimal_param, param_covariance = curve_fit(function, x, y, p0=initial_guesses, bounds=(lower_bounds, upper_bounds))
            
            return optimal_param, param_covariance
        except RuntimeError as e:
            return e

    def calculate_results(self, optimal_param, param_covariance, i, x, y, error):
        '''
        All the calculation with the results from one, two, and three decays happens here. The results are appended to the respective lists
        so that they can be plotted in the results window and saved to a file. To get a better overview of the used functions read the user manual.
        '''
        global temp_list
        global visc_list
        global q_list
        global Rh_list_1
        global Rh_list_2
        global Rh_list_3
        global Rh_error_1
        global Rh_error_2
        global Rh_error_3
        global pdi_list_1
        global pdi_list_2
        global pdi_list_3
        global pdi_error_1
        global pdi_error_2
        global pdi_error_3
        global ratio_1
        global ratio_2
        global ratio_3
        global ratio_1_error
        global ratio_2_error
        global ratio_3_error
        global correlation_x_list
        global correlation_y_list
        global chi_square_list
        global param_error

        param_error = np.sqrt(np.diag(param_covariance))
        
        if fit_type == 'One Decay' and optimal_param.any() != 0:
            Rh_list_1.append(constants.k * (temp_list[i] + 273.15) * q_list[i]**2 / (6 * pi * visc_list[i] / 1000 * optimal_param[2]))
            Rh_error_1.append(Rh_list_1[i] * param_error[2] / optimal_param[2])
            pdi_list_1.append(optimal_param[3] / optimal_param[2]**2)
            pdi_error_1.append(((1 / optimal_param[2]**2 * param_error[3])**2 + (-2 * optimal_param[3] / optimal_param[2]**3 * param_error[2])**2)**0.5)
            ratio_1.append(1)
            ratio_1_error.append(0)
            Nexp = self.f_one_decay(np.array(x), *optimal_param)
            r = [y[i] - Nexp[i] for i in range(len(x))]
            chi_square = 1 / (len(np.array(x)) - 5) * sum((np.array([r[i] for i in range(len(y)) if y[i] > 0.1 * max(y)]) / np.array([error[i] for i in range(len(y)) if y[i] > 0.1 * max(y)])) ** 2)
            chi_square_list.append(chi_square)
        elif (fit_type == 'Two Decays' or fit_type == 'Three Decays') and optimal_param.any() != 0:
            Rh_list_1.append(constants.k * (temp_list[i] + 273.15) * q_list[i]**2 / (6 * pi * visc_list[i] / 1000 * optimal_param[3]))
            Rh_error_1.append(Rh_list_1[i] * param_error[3] / optimal_param[3])
            pdi_list_1.append(optimal_param[4] / optimal_param[3]**2)
            pdi_error_1.append(((1 / optimal_param[3]**2 * param_error[4])**2 + (-2 * optimal_param[4] / optimal_param[3]**3 * param_error[3])**2)**0.5)
            Rh_list_2.append(constants.k * (temp_list[i] + 273.15) * q_list[i]**2 / (6 * pi * visc_list[i] / 1000 * optimal_param[7]))
            Rh_error_2.append(Rh_list_2[i] * param_error[7] / optimal_param[7])
            pdi_list_2.append(optimal_param[8] / optimal_param[7]**2)
            pdi_error_2.append(((1 / optimal_param[7]**2 * param_error[8])**2 + (-2 * optimal_param[8] / optimal_param[7]**3 * param_error[7])**2)**0.5)
            if fit_type == 'Two Decays':
                ratio_1.append(optimal_param[2] / (optimal_param[2] + optimal_param[6]))
                ratio_1_error.append((optimal_param[6] * param_error[2] - optimal_param[2] * param_error[6]) / (optimal_param[2] + optimal_param[6])**2)
                ratio_2.append(optimal_param[6] / (optimal_param[2] + optimal_param[6]))
                ratio_2_error.append((optimal_param[2] * param_error[6] - optimal_param[6] * param_error[2]) / (optimal_param[2] + optimal_param[6])**2)
                Nexp = self.f_two_decays(np.array(x), *optimal_param)
                r = [y[i] - Nexp[i] for i in range(len(x))]
                chi_square = 1 / (len(np.array(x)) - 10) * sum((np.array([r[i] for i in range(len(y)) if y[i] > 0.1 * max(y)]) / np.array([error[i] for i in range(len(y)) if y[i] > 0.1 * max(y)])) ** 2)
                chi_square_list.append(chi_square)
            else:
                ratio_1.append(optimal_param[2] / (optimal_param[2] + optimal_param[6] + optimal_param[10]))
                ratio_1_error.append(((optimal_param[6] + optimal_param[10]) * param_error[2] - optimal_param[2] * param_error[6] - optimal_param[2] * param_error[10]) / (optimal_param[2] + optimal_param[6] + optimal_param[10])**2)
                ratio_2.append(optimal_param[6] / (optimal_param[2] + optimal_param[6] + optimal_param[10]))
                ratio_2_error.append(((optimal_param[2] + optimal_param[10]) * param_error[6] - optimal_param[6] * param_error[2] - optimal_param[6] * param_error[10]) / (optimal_param[2] + optimal_param[6] + optimal_param[10])**2)
                Rh_list_3.append(constants.k * (temp_list[i] + 273.15) * q_list[i]**2 / (6 * pi * visc_list[i] / 1000 * optimal_param[11]))
                Rh_error_3.append(Rh_list_3[i] * param_error[11] / optimal_param[11])
                pdi_list_3.append(optimal_param[12] / optimal_param[11]**2)
                pdi_error_3.append(((1 / optimal_param[11]**2 * param_error[12])**2 + (-2 * optimal_param[12] / optimal_param[11]**3 * param_error[11])**2)**0.5)
                ratio_3.append(optimal_param[10] / (optimal_param[2] + optimal_param[6] + optimal_param[10]))
                ratio_3_error.append(((optimal_param[2] + optimal_param[6]) * param_error[10] - optimal_param[10] * param_error[2] - optimal_param[10] * param_error[6]) / (optimal_param[2] + optimal_param[6] + optimal_param[10])**2)
                Nexp = self.f_three_decays(np.array(x), *optimal_param)
                r = [y[i] - Nexp[i] for i in range(len(x))]
                chi_square = 1 / (len(np.array(x)) - 14) * sum((np.array([r[i] for i in range(len(y)) if y[i] > 0.1 * max(y)]) / np.array([error[i] for i in range(len(y)) if y[i] > 0.1 * max(y)])) ** 2)
                chi_square_list.append(chi_square)
        else:
            Rh_list_1.append(float('NaN'))
            Rh_list_2.append(float('NaN'))
            Rh_list_3.append(float('NaN'))
            Rh_error_1.append(float('NaN'))
            Rh_error_2.append(float('NaN'))
            Rh_error_3.append(float('NaN'))
            pdi_list_1.append(float('NaN'))
            pdi_list_2.append(float('NaN'))
            pdi_list_3.append(float('NaN'))
            pdi_error_1.append(float('NaN'))
            pdi_error_2.append(float('NaN'))
            pdi_error_3.append(float('NaN'))
            ratio_1.append(float('NaN'))
            ratio_2.append(float('NaN'))
            ratio_3.append(float('NaN'))
            ratio_1_error.append(float('NaN'))
            ratio_2_error.append(float('NaN'))
            ratio_3_error.append(float('NaN'))
            chi_square_list.append(float('NaN'))


    def fit_data(self):
        '''
        Begin of the fit procedure.
        The initial lists of correlation functions and error data are normalized, sliced according to the fit limits, and given to the fit function.
        The results are appended to the lists used for result visualization in the result window and are written into the result files during saving.
        It is also distinguished between different fit parameters that are set during fit initialization by clicking the ckeckboxes 'differs from default'
        or 'exclude from fit'. In the first case the different fit parameters are used for the fit procedure, while in the second case only NaNs are written.
        '''
        global progress_counter
        global scan_list
        global correlation_x_list
        global correlation_y_list
        global fit_results
        global fit_error
        global scan_list_fit
        global initialization_visible
        global result_visible
        global fit_parameters
        global param_error
        global Rh_list_1
        global Rh_list_2
        global Rh_list_3
        global Rh_error_1
        global Rh_error_2
        global Rh_error_3
        global pdi_list_1
        global pdi_list_2
        global pdi_list_3
        global pdi_error_1
        global pdi_error_2
        global pdi_error_3
        global ratio_1
        global ratio_2
        global ratio_3
        global ratio_1_error
        global ratio_2_error
        global ratio_3_error
        global chi_square_list
        Rh_list_1 = []
        Rh_list_2 = []        
        Rh_list_3 = []        
        Rh_error_1 = []        
        Rh_error_2 = []        
        Rh_error_3 = []        
        pdi_list_1 = []        
        pdi_list_2 = []        
        pdi_list_3 = []        
        pdi_error_1 = []
        pdi_error_2 = []
        pdi_error_3 = []        
        ratio_1 = []        
        ratio_2 = []        
        ratio_3 = []        
        ratio_1_error = []        
        ratio_2_error = []        
        ratio_3_error = []
        chi_square_list = []
        fit_results = []
        fit_error = []
        param_error = []
        progress_counter = 0
        initialization_visible = False
        result_visible = False
        if fit_type == '':
            return
        if fit_type == 'Contin':
            self.fit_contin()
            return
        self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Fitting...'))
        try:
            for i in range(len(scan_list)):
                if scan_list_fit[i] == True:
                    x, y, error, baseline = self.normalize_correlation_lists(correlation_x_list[i], correlation_y_list[i], corr_error_list[i], fit_parameters[8], fit_parameters[9], fit_parameters[10], fit_parameters[11], fit_parameters[12], fit_parameters[13])
                    x, y, error = self.slice_correlation_lists(correlation_x_list[i], correlation_y_list[i], corr_error_list[i], fit_parameters[6], fit_parameters[7])
                    if fit_type == 'One Decay':
                        initial_guesses = (baseline, 1, fit_parameters[0], (0.1 * fit_parameters[0]**2)**0.5, fit_parameters[0] ** 2)
                        lower_bounds = [baseline - 0.001, fit_parameters[14], 1 / fit_parameters[17], 0, - 1 / fit_parameters[17] ** 3]
                        upper_bounds = [baseline + 0.001, fit_parameters[15], 1 / fit_parameters[16], np.PINF, 1 / fit_parameters[16] ** 3]
                        optimal_param, param_covariance = self.fit_function(self.f_one_decay, x, y, error, initial_guesses, lower_bounds, upper_bounds)
                        self.calculate_results(optimal_param, param_covariance, i, x, y, error)
                    elif fit_type == 'Two Decays':
                        initial_guesses = (baseline, 1,  fit_parameters[3], fit_parameters[0], (0.1 * fit_parameters[0]**2)**0.5, fit_parameters[0] ** 2, fit_parameters[4], fit_parameters[1], (0.1 * fit_parameters[1]**2)**0.5, fit_parameters[1] ** 2)
                        lower_bounds = [baseline - 0.001, fit_parameters[14], 1 - fit_parameters[23], 1 / fit_parameters[17], 0, - 1 / fit_parameters[17] ** 3, fit_parameters[22], 1 / fit_parameters[19], 0, - 1 / fit_parameters[19] ** 3]
                        upper_bounds = [baseline + 0.001, fit_parameters[15], 1 - fit_parameters[22], 1 / fit_parameters[16], np.PINF, 1 / fit_parameters[16] ** 3, fit_parameters[23], 1 / fit_parameters[18], np.PINF, 1 / fit_parameters[18] ** 3]
                        optimal_param, param_covariance = self.fit_function(self.f_two_decays, x, y, error, initial_guesses, lower_bounds, upper_bounds)
                        self.calculate_results(optimal_param, param_covariance, i, x, y, error)
                    elif fit_type == 'Three Decays':
                        initial_guesses = (baseline, 1,  fit_parameters[3], fit_parameters[0], (0.1 * fit_parameters[0]**2)**0.5, fit_parameters[0] ** 2, fit_parameters[4], fit_parameters[1], (0.1 * fit_parameters[1]**2)**0.5, fit_parameters[1] ** 2, fit_parameters[5], fit_parameters[2], (0.1 * fit_parameters[2]**2)**0.5, fit_parameters[1] ** 2)
                        lower_bounds = [baseline - 0.001, fit_parameters[14], 1 - fit_parameters[23] - fit_parameters[25], 1 / fit_parameters[17], 0, - 1 / fit_parameters[17] ** 3, fit_parameters[22], 1 / fit_parameters[19], 0, - 1 / fit_parameters[19] ** 3, fit_parameters[24], 1 / fit_parameters[21], 0, - 1 / fit_parameters[21] ** 3]
                        upper_bounds = [baseline + 0.001, fit_parameters[15], 1 - fit_parameters[22] - fit_parameters[24], 1 / fit_parameters[16], np.PINF, 1 / fit_parameters[16] ** 3, fit_parameters[23], 1 / fit_parameters[18], np.PINF, 1 / fit_parameters[18] ** 3, fit_parameters[25], 1 / fit_parameters[20], np.PINF, 1 / fit_parameters[20] ** 3]
                        optimal_param, param_covariance = self.fit_function(self.f_three_decays, x, y, error, initial_guesses, lower_bounds, upper_bounds)
                        self.calculate_results(optimal_param, param_covariance, i, x, y, error)
                    if fit_type != 'Contin':
                        fit_results.append(optimal_param)
                        fit_error.append(param_error)
                elif scan_list_fit[i] == False:
                    if fit_type == 'One Decay':
                        fit_results.append([float('NaN') for i in range(5)])
                        fit_error.append([float('NaN') for i in range(5)])
                    elif fit_type == 'Two Decays':
                        fit_results.append([float('NaN') for i in range(10)])
                        fit_error.append([float('NaN') for i in range(10)])
                    elif fit_type == 'Three Decays':
                        fit_results.append([float('NaN') for i in range(14)])
                        fit_error.append([float('NaN') for i in range(14)])
                    self.calculate_results(np.array([0]), np.array([0]), np.array([0]), np.array([0]), np.array([0]), np.array([0]))
                else:
                    x, y, error, baseline = self.normalize_correlation_lists(correlation_x_list[i], correlation_y_list[i], corr_error_list[i], scan_list_fit[i][8], scan_list_fit[i][9], scan_list_fit[i][10], scan_list_fit[i][11], scan_list_fit[i][12], scan_list_fit[i][13])
                    x, y, error = self.slice_correlation_lists(correlation_x_list[i], correlation_y_list[i], corr_error_list[i], scan_list_fit[i][6], scan_list_fit[i][7])
                    if fit_type == 'One Decay':
                        initial_guesses = (baseline, 1, scan_list_fit[i][0], (0.1 * scan_list_fit[i][0]**2)**0.5, scan_list_fit[i][0]**2)
                        lower_bounds = [baseline - 0.001, scan_list_fit[i][14], 1 / scan_list_fit[i][17], 0, - 1 / scan_list_fit[i][17] ** 3]
                        upper_bounds = [baseline + 0.001, scan_list_fit[i][15], 1 / scan_list_fit[i][16], np.PINF, 1 / scan_list_fit[i][16] ** 3]
                        optimal_param, param_covariance = self.fit_function(self.f_one_decay, x, y, error, initial_guesses, lower_bounds, upper_bounds)
                        self.calculate_results(optimal_param, param_covariance, i, x, y, error)
                    elif fit_type == 'Two Decays':
                        initial_guesses = (baseline, 1,  scan_list_fit[i][3], scan_list_fit[i][0], (0.1 * scan_list_fit[i][0]**2)**0.5, scan_list_fit[i][0]**2, scan_list_fit[i][4], scan_list_fit[i][1], (0.1 * scan_list_fit[i][1]**2)**0.5, scan_list_fit[i][1]**2)
                        lower_bounds = [baseline - 0.001, scan_list_fit[i][14], 1 - scan_list_fit[i][23], 1 / scan_list_fit[i][17], 0, - 1 / scan_list_fit[i][17] ** 3, scan_list_fit[i][22], 1 / scan_list_fit[i][19], 0, - 1 / scan_list_fit[i][19] ** 3]
                        upper_bounds = [baseline + 0.001, scan_list_fit[i][15], 1 - scan_list_fit[i][22], 1 / scan_list_fit[i][16], np.PINF, np.PINF, scan_list_fit[i][23], 1 / scan_list_fit[i][18], np.PINF, np.PINF]
                        optimal_param, param_covariance = self.fit_function(self.f_two_decays, x, y, error, initial_guesses, lower_bounds, upper_bounds)
                        self.calculate_results(optimal_param, param_covariance, i, x, y, error)
                    elif fit_type == 'Three Decays':
                        initial_guesses = (baseline, 1,  scan_list_fit[i][3], scan_list_fit[i][0], (0.1 * scan_list_fit[i][0]**2)**0.5, scan_list_fit[i][0]**2, scan_list_fit[i][4], scan_list_fit[i][1], (0.1 * scan_list_fit[i][1]**2)**0.5, scan_list_fit[i][1]**2, scan_list_fit[i][5], scan_list_fit[i][2], (0.1 * scan_list_fit[i][2]**2)**0.5, scan_list_fit[i][2]**2)
                        lower_bounds = [baseline - 0.001, scan_list_fit[i][14], 1 - scan_list_fit[i][23] - scan_list_fit[i][25], 1 / scan_list_fit[i][17], 0, - 1 / scan_list_fit[i][17] ** 3, scan_list_fit[i][22], 1 / scan_list_fit[i][19], 0, - 1 / scan_list_fit[i][19] ** 3, scan_list_fit[i][24], 1 / scan_list_fit[i][21], 0, - 1 / scan_list_fit[i][21] ** 3]
                        upper_bounds = [baseline + 0.001, scan_list_fit[i][15], 1 - scan_list_fit[i][22] - scan_list_fit[i][24], 1 / scan_list_fit[i][16], np.PINF, 1 / scan_list_fit[i][16] ** 3, scan_list_fit[i][23], 1 / scan_list_fit[i][18], np.PINF, 1 / scan_list_fit[i][18] ** 3, scan_list_fit[i][25], 1 / scan_list_fit[i][20], np.PINF, 1 / scan_list_fit[i][20] ** 3]
                        optimal_param, param_covariance = self.fit_function(self.f_three_decays, x, y, error, initial_guesses, lower_bounds, upper_bounds)
                        self.calculate_results(optimal_param, param_covariance, i, x, y, error)
                    fit_results.append(optimal_param)
                    fit_error.append(param_error)
                self.update_progress_fit()
            fit_results = np.array(fit_results)
            fit_error = np.array(fit_error)
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Done fitting!'))
        except ValueError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Choose better fit values!'))
        except TypeError:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Runtime Error: Choose other Params'))
        

    def fit_contin(self):
        '''
        CONTIN fit procedure. At first the correlation lists and error lists (actually not used) are normalized and sliced. Then the data are given to the
        runCONTINfit function that is nested inside the pyCONTINwrapper module that is a wrapper around the Fortran66 code from W. Provencher that computes
        the inverse Laplace transform of the data. This also uses the contin.in, contin.for, and contin.out files in the parent folder.
        Additionally, the output file of this procedure is read that gives the distribution of gamma values or the probability of the respective gamma value
        in a range of gammas that is given by the 'Fit g1 from' and 'Fit g1 to' values set in the fit initialization.
        In the end, the distribution of radii is calculated from the distribution of gammas. Since this distribution is unweighted at first, the volume weighted
        and intensity weighted distributions of radii are calculated as well.
        '''
        global size_distributions
        global size_distributions_volume
        global size_distributions_intensity
        global progress_counter
        progress_counter = 0
        size_distributions = []
        size_distributions_volume = []
        size_distributions_intensity = []
        if scan_list == []:
            return
        self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Fitting...'))
        for i in range(len(scan_list)):
            if scan_list_fit[i] == True:
                x, y, error, baseline = self.normalize_correlation_lists(correlation_x_list[i], correlation_y_list[i], corr_error_list[i], fit_parameters[8], fit_parameters[9], fit_parameters[10], fit_parameters[11], fit_parameters[12], fit_parameters[13])
                x, y, error = self.slice_correlation_lists(correlation_x_list[i], correlation_y_list[i], corr_error_list[i], fit_parameters[6], fit_parameters[7])
            elif scan_list_fit[i] == False:
                pass
            else:
                x, y, error, baseline = self.normalize_correlation_lists(correlation_x_list[i], correlation_y_list[i], corr_error_list[i], scan_list_fit[i][8], scan_list_fit[i][9], scan_list_fit[i][10], scan_list_fit[i][11], scan_list_fit[i][12], scan_list_fit[i][13])
                x, y, error = self.slice_correlation_lists(correlation_x_list[i], correlation_y_list[i], corr_error_list[i], scan_list_fit[i][6], scan_list_fit[i][7])
            alldata = runCONTINfit(np.array(x), np.sqrt(np.absolute(np.array(y))), contin_parameters)
            gamma_values = alldata[2][1][:-int(float(num_data_points) / 10), 2]
            prob_gamma = alldata[2][1][:-int(float(num_data_points) / 10), 0]
            prob_gamma = [prob_gamma[num] / integrate.simps(prob_gamma, gamma_values) for num in range(len(prob_gamma))]
            gamma_error = alldata[2][1][:-int(float(num_data_points) / 10), 1]
            c = constants.k * (temp_list[i] + 273.15) * q_list[i]**2 / (6 * pi * visc_list[i] / 1000)
            radius_values = [c / num for num in gamma_values]
            radius_values = radius_values[::-1]
            prob_radius = [prob_gamma[::-1][num] * c / radius_values[num] ** 2 for num in range(len(prob_gamma))]
            radius_error = [gamma_error[::-1][num] * c / radius_values[num] ** 2 for num in range(len(gamma_error))]

            prob_radius_volume_weighted = [prob_radius[num] / radius_values[num]**3 for num in range(len(prob_radius))]
            prob_radius_volume_weighted = [prob_radius_volume_weighted[num] / integrate.simps(prob_radius_volume_weighted, radius_values) for num in range(len(prob_radius_volume_weighted))]
            radius_error_volume_weighted = [radius_error[num] / prob_radius[num] * prob_radius_volume_weighted[num] for num in range(len(radius_error))]

            prob_radius_intensity_weighted = [prob_radius[num] / radius_values[num]**6 for num in range(len(prob_radius))]
            prob_radius_intensity_weighted = [prob_radius_intensity_weighted[num] / integrate.simps(prob_radius_intensity_weighted, radius_values) for num in range(len(prob_radius_intensity_weighted))]
            radius_error_intensity_weighted = [radius_error[num] / prob_radius[num] * prob_radius_intensity_weighted[num] for num in range(len(radius_error))]

            radius_values = [num * 1e9 for num in radius_values]

            size_distributions.append(radius_values)
            size_distributions.append(prob_radius)
            size_distributions.append(radius_error)
            size_distributions_volume.append(radius_values)
            size_distributions_volume.append(prob_radius_volume_weighted)
            size_distributions_volume.append(radius_error_volume_weighted)
            size_distributions_intensity.append(radius_values)
            size_distributions_intensity.append(prob_radius_intensity_weighted)
            size_distributions_intensity.append(radius_error_intensity_weighted)
            self.update_progress_fit()
        self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Done fitting!'))

        # The input and output files for the CONTIN procedure are deleted immediately after the fit.
        if os.path.isfile('CONTIN/CONTINInput.txt'):
            os.remove('CONTIN/CONTINInput.txt')
        else:
            print('File not in directory')
        if os.path.isfile('CONTIN/CONTINOutput.txt'):
            os.remove('CONTIN/CONTINOutput.txt')
        else:
            print('File not in directory')
        self.display_result_window()

    def find_limits(self, correlation_x, lower, upper):
        #Finds the list indices of the given upper and lower limits in the list of x-values.
        lower_lim = 0
        upper_lim = len(correlation_x)
        for num in range(len(correlation_x)):
            if correlation_x[num] > lower:
                lower_lim = num
                break
        for num in range(len(correlation_x)):
            if correlation_x[num] < upper:
                upper_lim = num
        return lower_lim, upper_lim

    def normalize_correlation_lists(self, correlation_x, correlation_y, corr_error, base_x_from, base_x_to, cont_x_from, cont_x_to, base_y_from, base_y_to):
        # Normalization of the input correlation and error data according to the given fit limits.
        lower_lim, upper_lim = self.find_limits(correlation_x, base_x_from, base_x_to)
        new_correlation_y = [i for i in correlation_y]
        new_corr_error = [i for i in corr_error]
        for num in range(len(new_correlation_y)):
                new_correlation_y[num] = new_correlation_y[num] - min(new_correlation_y[lower_lim:upper_lim])
                new_corr_error[num] = new_corr_error[num] - min(new_correlation_y[lower_lim:upper_lim])
        baseline = min(correlation_y[lower_lim:upper_lim])

        lower_lim, upper_lim = self.find_limits(correlation_x, cont_x_from, cont_x_to)
        for num in range(len(new_correlation_y)):
            new_correlation_y[num] = new_correlation_y[num] / max(new_correlation_y[lower_lim:upper_lim])
            new_corr_error[num] = new_corr_error[num] / max(new_correlation_y[lower_lim:upper_lim])
        return correlation_x, new_correlation_y, new_corr_error, baseline

    def slice_correlation_lists(self, correlation_x, correlation_y, corr_error, g1_from, g1_to):
        # Slices the input correlation and error data lists according to the fit limits.
        lower_lim, upper_lim = self.find_limits(correlation_x, g1_from, g1_to)
        return correlation_x[lower_lim:upper_lim], correlation_y[lower_lim:upper_lim], corr_error[lower_lim:upper_lim]

    def show_fit_result(self):
        # Shows the fit result lines in the MainWindow to check whether the fit parameters actually fit to the data.
        global initialization_visible
        global result_visible
        initialization_visible = False
        result_visible = True
        self.graph_update()

    def display_result_window(self):
        '''
        Initializes the result window after the fit is made and all calculations are done. This function distinguishes between
        the cumulant fits and CONTIN fit and opens the respective result window.
        '''
        if len(Rh_list_1) > 0 and fit_type != 'Contin':
            self.other_uig = DLS_Results()
            self.other_uig.__init__()
            self.other_uig.show()
        elif fit_type == 'Contin' and len(size_distributions) > 0:
            self.other_ui_contin = DLS_CONTIN()
            self.other_ui_contin.__init__()
            self.other_ui_contin.show()
        else:
            self.ui.updateMessages.setText(QtCore.QCoreApplication.translate("MainWindow", 'Please make a fit first!'))


class MplWidget(QWidget):
    '''
    This class is used to create the matplotlib canvas for the MainWindow where all the data and functions are plotted.
    '''
    
    def __init__(self, parent = None):

        QWidget.__init__(self, parent)
        
        self.canvas = FigureCanvas(Figure(figsize=(17, 1), tight_layout=True))
        toolbar = NavigationToolbar(self.canvas, self)
        
        self.vertical_layout = QVBoxLayout()
        self.vertical_layout.addWidget(self.canvas)
        self.vertical_layout.addWidget(toolbar)
        
        self.canvas.axes = self.canvas.figure.add_subplot(211)
        self.canvas.axes.set_xscale('log')
        self.canvas.axes.set_ylabel(r'normalized $g_2$($\tau$)', fontsize=plot_main_fontsize)
        self.canvas.axes2 = self.canvas.figure.add_subplot(212)
        self.canvas.axes2.set_yscale('log')
        self.canvas.axes2.set_xlim(plot_2_xlim)
        self.canvas.axes2.set_ylim(plot_2_ylim)
        self.canvas.axes2.set_xlabel(r'$Time$ / s', fontsize=plot_main_fontsize)
        self.canvas.axes2.set_ylabel(r'normalized $g_2$($\tau$)', fontsize=plot_main_fontsize)
        self.setLayout(self.vertical_layout)


class MplResults(QWidget):
    '''
    This class is used to initialize the matplotlib canvas in the results windows for the cumulant and CONTIN fits.
    '''
    
    def __init__(self, parent = None):

        QWidget.__init__(self, parent)
        
        self.canvas = FigureCanvas(Figure(tight_layout=True))
        toolbar = NavigationToolbar(self.canvas, self)
        
        self.horizontal_layout = QVBoxLayout()
        self.horizontal_layout.addWidget(self.canvas)
        self.horizontal_layout.addWidget(toolbar)
        
        self.canvas.axes = self.canvas.figure.add_subplot(111)
        self.setLayout(self.horizontal_layout)
        

class DLS_Fit_Init(QtWidgets.QMainWindow):
    '''
    This class sets up all the features for the fit initialization GUI. It is based on the DLS_Fit_Init_baseclass which should not be modified or at least
    no important feature should be removed that is used here to ensure full functionality.
    '''
    def __init__(self):
        super(DLS_Fit_Init, self).__init__()
        self.uif = DLS_Fit_Init_baseclass.Ui_MainWindow()
        self.uif.setupUi(self)
        self.uif.fitType.addItems(['', 'One Decay', 'Two Decays', 'Three Decays', 'Contin'])

        QShortcut(QKeySequence('F5'), self, self.plot_update)
        self.update()

    def closeEvent(self, event):
        # When the window is closed and the Set Button has not been pressed before, the actual values are set as default.
        actual_parameters = [gamma_a, gamma_b, gamma_c, fraction_a, fraction_b, fraction_c, g1_from, g1_to, baseline_x_from, baseline_x_to,
                            contrast_x_from, contrast_x_to, baseline_y_from, baseline_y_to, contrast_y_from, contrast_y_to, tau_a_from, tau_a_to,
                            tau_b_from, tau_b_to, tau_c_from, tau_c_to, fraction_b_from, fraction_b_to, fraction_c_from, fraction_c_to]
        if actual_parameters == fit_parameters or fit_parameters == [0 for i in range(26)]:
            self.set_default_values()
        self.plot_update()
        event.accept()

    def round_to_n(self, x, n):
        # Function to round to a specific number of significant digits.
        if x == 0: return x
        return round(x, -int(floor(log10(abs(x)))) + (n - 1))

    def update(self):
        # Updates all the output in the Fit Initialization Window when the Scan Number Field in the MainWindow is changed. This function also connects all
        # signals and slots to ensure update of the global variables when some value is changed.
        global scan_list_fit
        global actual_scan

        if fit_type == '':
            self.uif.fitType.setCurrentIndex(0)
        elif fit_type == 'One Decay':
            self.uif.fitType.setCurrentIndex(1)
        elif fit_type == 'Two Decays':
            self.uif.fitType.setCurrentIndex(2)
        elif fit_type == 'Three Decays':
            self.uif.fitType.setCurrentIndex(3)
        elif fit_type == 'Contin':
            self.uif.fitType.setCurrentIndex(4)

        if scan_list_fit[actual_scan] == True:
            self.uif.notFit.setChecked(False)
            self.uif.notDefault.setChecked(False)
        elif scan_list_fit[actual_scan] == False:
            self.uif.notFit.setChecked(True)
            self.uif.notDefault.setChecked(False)
        else:
            self.uif.notDefault.setChecked(True)
            self.uif.notFit.setChecked(False)
        self.uif.gammaA.setText(QtCore.QCoreApplication.translate("Main Window", str(gamma_a)))
        self.uif.gammaB.setText(QtCore.QCoreApplication.translate("Main Window", str(gamma_b)))
        self.uif.gammaC.setText(QtCore.QCoreApplication.translate("Main Window", str(gamma_c)))
        self.uif.fractionA.setText(QtCore.QCoreApplication.translate("Main Window", str(fraction_a)))
        self.uif.fractionB.setText(QtCore.QCoreApplication.translate("Main Window", str(fraction_b)))
        self.uif.fractionC.setText(QtCore.QCoreApplication.translate("Main Window", str(fraction_c)))
        self.uif.fitFrom.setText(QtCore.QCoreApplication.translate("Main Window", str(self.round_to_n(g1_from, 3))))
        self.uif.fitTo.setText(QtCore.QCoreApplication.translate("Main Window", str(self.round_to_n(g1_to, 3))))
        self.uif.baselineXFrom.setText(QtCore.QCoreApplication.translate("Main Window", str(self.round_to_n(baseline_x_from, 3))))
        self.uif.baselineXTo.setText(QtCore.QCoreApplication.translate("Main Window", str(self.round_to_n(baseline_x_to, 3))))
        self.uif.contrastXFrom.setText(QtCore.QCoreApplication.translate("Main Window", str(self.round_to_n(contrast_x_from, 3))))
        self.uif.contrastXTo.setText(QtCore.QCoreApplication.translate("Main Window", str(self.round_to_n(contrast_x_to, 3))))
        self.uif.baselineYFrom.setText(QtCore.QCoreApplication.translate("Main Window", str(self.round_to_n(baseline_y_from, 3))))
        self.uif.baselineYTo.setText(QtCore.QCoreApplication.translate("Main Window", str(self.round_to_n(baseline_y_to, 3))))
        self.uif.contrastYFrom.setText(QtCore.QCoreApplication.translate("Main Window", str(self.round_to_n(contrast_y_from, 3))))
        self.uif.contrastYTo.setText(QtCore.QCoreApplication.translate("Main Window", str(self.round_to_n(contrast_y_to, 3))))
        self.uif.tauAFrom.setText(QtCore.QCoreApplication.translate("Main Window", str(tau_a_from)))
        self.uif.tauATo.setText(QtCore.QCoreApplication.translate("Main Window", str(tau_a_to)))
        self.uif.tauBFrom.setText(QtCore.QCoreApplication.translate("Main Window", str(tau_b_from)))
        self.uif.tauBTo.setText(QtCore.QCoreApplication.translate("Main Window", str(tau_b_to)))
        self.uif.tauCFrom.setText(QtCore.QCoreApplication.translate("Main Window", str(tau_c_from)))
        self.uif.tauCTo.setText(QtCore.QCoreApplication.translate("Main Window", str(tau_c_to)))
        self.uif.fractionBFrom.setText(QtCore.QCoreApplication.translate("Main Window", str(fraction_b_from)))
        self.uif.fractionBTo.setText(QtCore.QCoreApplication.translate("Main Window", str(fraction_b_to)))
        self.uif.fractionCFrom.setText(QtCore.QCoreApplication.translate("Main Window", str(fraction_c_from)))
        self.uif.fractionCTo.setText(QtCore.QCoreApplication.translate("Main Window", str(fraction_c_to)))

        self.uif.fitType.currentTextChanged.connect(self.set_fit_type)

        self.uif.setDefault.clicked.connect(self.set_default_values)

        self.uif.gammaA.textChanged.connect(self.set_config)
        self.uif.gammaB.textChanged.connect(self.set_config)
        self.uif.gammaC.textChanged.connect(self.set_config)
        self.uif.fractionA.textChanged.connect(self.set_config)
        self.uif.fractionB.textChanged.connect(self.set_config)
        self.uif.fractionC.textChanged.connect(self.set_config)
        self.uif.fitFrom.textChanged.connect(self.set_config)
        self.uif.fitTo.textChanged.connect(self.set_config)
        self.uif.baselineXFrom.textChanged.connect(self.set_config_x)
        self.uif.baselineXTo.textChanged.connect(self.set_config_x)
        self.uif.contrastXFrom.textChanged.connect(self.set_config_x)
        self.uif.contrastXTo.textChanged.connect(self.set_config_x)
        self.uif.baselineYFrom.textChanged.connect(self.set_config_y)
        self.uif.baselineYTo.textChanged.connect(self.set_config_y)
        self.uif.contrastYFrom.textChanged.connect(self.set_config_y)
        self.uif.contrastYTo.textChanged.connect(self.set_config_y)
        self.uif.tauAFrom.textChanged.connect(self.set_config)
        self.uif.tauATo.textChanged.connect(self.set_config)
        self.uif.tauBFrom.textChanged.connect(self.set_config)
        self.uif.tauBTo.textChanged.connect(self.set_config)
        self.uif.tauCFrom.textChanged.connect(self.set_config)
        self.uif.tauCTo.textChanged.connect(self.set_config)
        self.uif.fractionBFrom.textChanged.connect(self.set_config)
        self.uif.fractionBTo.textChanged.connect(self.set_config)
        self.uif.fractionCFrom.textChanged.connect(self.set_config)
        self.uif.fractionCTo.textChanged.connect(self.set_config)

        self.uif.notFit.stateChanged.connect(self.set_not_fit)
        self.uif.notDefault.stateChanged.connect(self.set_not_default)

    def set_fit_type(self):
        # Sets the actual fit type when the dropdown menu is changed and enables or disables the manipulation of all relevant LineEdits according to the chosen Fit Type.

        global fit_type
        fit_type = self.uif.fitType.currentText()

        if fit_type == 'One Decay':
            self.uif.gammaB.setReadOnly(True)
            self.uif.fractionA.setReadOnly(True)
            self.uif.fractionB.setReadOnly(True)
            self.uif.tauBFrom.setReadOnly(True)
            self.uif.tauBTo.setReadOnly(True)
            self.uif.fractionBFrom.setReadOnly(True)
            self.uif.fractionBTo.setReadOnly(True)
            self.uif.gammaC.setReadOnly(True)
            self.uif.fractionC.setReadOnly(True)
            self.uif.tauCFrom.setReadOnly(True)
            self.uif.tauCTo.setReadOnly(True)
            self.uif.fractionCFrom.setReadOnly(True)
            self.uif.fractionCTo.setReadOnly(True)
        elif fit_type == 'Two Decays':
            self.uif.gammaB.setReadOnly(False)
            self.uif.fractionA.setReadOnly(False)
            self.uif.fractionB.setReadOnly(False)
            self.uif.tauBFrom.setReadOnly(False)
            self.uif.tauBTo.setReadOnly(False)
            self.uif.fractionBFrom.setReadOnly(False)
            self.uif.fractionBTo.setReadOnly(False)
            self.uif.gammaC.setReadOnly(True)
            self.uif.fractionC.setReadOnly(True)
            self.uif.tauCFrom.setReadOnly(True)
            self.uif.tauCTo.setReadOnly(True)
            self.uif.fractionCFrom.setReadOnly(True)
            self.uif.fractionCTo.setReadOnly(True)
        elif fit_type == 'Three Decays' or fit_type == '' or fit_type == 'Contin':
            self.uif.gammaB.setReadOnly(False)
            self.uif.fractionA.setReadOnly(False)
            self.uif.fractionB.setReadOnly(False)
            self.uif.tauBFrom.setReadOnly(False)
            self.uif.tauBTo.setReadOnly(False)
            self.uif.fractionBFrom.setReadOnly(False)
            self.uif.fractionBTo.setReadOnly(False)
            self.uif.gammaC.setReadOnly(False)
            self.uif.fractionC.setReadOnly(False)
            self.uif.tauCFrom.setReadOnly(False)
            self.uif.tauCTo.setReadOnly(False)
            self.uif.fractionCFrom.setReadOnly(False)
            self.uif.fractionCTo.setReadOnly(False)

    def set_default_values(self):
        # Sets the default values when the Set button is pressed or the window is closed when nothing has been pressed before.

        global fit_parameters

        fit_parameters[0] = gamma_a
        fit_parameters[6] = g1_from
        fit_parameters[7] = g1_to
        fit_parameters[8] = baseline_x_from
        fit_parameters[9] = baseline_x_to
        fit_parameters[10] = contrast_x_from
        fit_parameters[11] = contrast_x_to
        fit_parameters[12] = baseline_y_from
        fit_parameters[13] = baseline_y_to
        fit_parameters[14] = contrast_y_from
        fit_parameters[15] = contrast_y_to
        fit_parameters[16] = tau_a_from
        fit_parameters[17] = tau_a_to

        fit_parameters[1] = gamma_b
        fit_parameters[3] = fraction_a
        fit_parameters[4] = fraction_b
        fit_parameters[18] = tau_b_from
        fit_parameters[19] = tau_b_to
        fit_parameters[22] = fraction_b_from
        fit_parameters[23] = fraction_b_to

        fit_parameters[2] = gamma_c
        fit_parameters[5] = fraction_c
        fit_parameters[20] = tau_c_from
        fit_parameters[21] = tau_c_to
        fit_parameters[24] = fraction_c_from
        fit_parameters[25] = fraction_c_to

        try:
            contin_parameters[2][2] = float(1 / g1_to)
            contin_parameters[3][2] = float(1 / g1_from)
        except ZeroDivisionError:
            pass

    def set_config(self):
        # Changes the config data when the values in the LineEdits are changed.
        global gamma_a
        global gamma_b
        global gamma_c
        global fraction_a
        global fraction_b
        global fraction_c
        global g1_from
        global g1_to
        global tau_a_from
        global tau_a_to
        global tau_b_from
        global tau_b_to
        global tau_c_from
        global tau_c_to
        global fraction_b_from
        global fraction_b_to
        global fraction_c_from
        global fraction_c_to

        try:
            gamma_a = float(self.uif.gammaA.text())
            gamma_b = float(self.uif.gammaB.text())
            gamma_c = float(self.uif.gammaC.text())
            fraction_a = float(self.uif.fractionA.text())
            fraction_b = float(self.uif.fractionB.text())
            fraction_c = float(self.uif.fractionC.text())
            g1_from = float(self.uif.fitFrom.text())
            g1_to = float(self.uif.fitTo.text())
            contin_parameters[2][2] = float(1 / g1_to)
            contin_parameters[3][2] = float(1 / g1_from)
            
            tau_a_from = float(self.uif.tauAFrom.text())
            tau_a_to = float(self.uif.tauATo.text())
            tau_b_from = float(self.uif.tauBFrom.text())
            tau_b_to = float(self.uif.tauBTo.text())
            tau_c_from = float(self.uif.tauCFrom.text())
            tau_c_to = float(self.uif.tauCTo.text())
            fraction_b_from = float(self.uif.fractionBFrom.text())
            fraction_b_to = float(self.uif.fractionBTo.text())
            fraction_c_from = float(self.uif.fractionCFrom.text())
            fraction_c_to = float(self.uif.fractionCTo.text())
        except ValueError:
            pass
        except ZeroDivisionError:
            pass

    def set_config_x(self):
        # The task of the function above is splitted.
        global baseline_x_from
        global baseline_x_to
        global contrast_x_from
        global contrast_x_to
        try:
            baseline_x_from = float(self.uif.baselineXFrom.text())
            baseline_x_to = float(self.uif.baselineXTo.text())
            contrast_x_from = float(self.uif.contrastXFrom.text())
            contrast_x_to = float(self.uif.contrastXTo.text())
        except ValueError:
            pass

    def set_config_y(self):
        # See above.
        global baseline_y_from
        global baseline_y_to
        global contrast_y_from
        global contrast_y_to
        try:
            baseline_y_from = float(self.uif.baselineYFrom.text())
            baseline_y_to = float(self.uif.baselineYTo.text())
            contrast_y_from = float(self.uif.contrastYFrom.text())
            contrast_y_to = float(self.uif.contrastYTo.text())
        except ValueError:
            pass

    def plot_update(self):
        # When a value is changed the user can press the F5 button to change the output in the MainWindow and update the graphs.
        DLS_Main.graph_update(window)

    def set_not_fit(self):
        # When the 'exclude from fit' button is clicked the scan_list_fit list is updated to ensure that the data set is not included in the fit procedure.
        global scan_list_fit
        global actual_scan
        if self.uif.notFit.isChecked():
            self.uif.notDefault.setChecked(False)
            scan_list_fit[actual_scan] = False
        else:
            scan_list_fit[actual_scan] = True

    def set_not_default(self):
        # When the 'differs from default' button is clicked the actual parameters are stored in the scan_list_fit list and used for the fit procedure.
        global scan_list_fit
        global actual_scan
        if self.uif.notDefault.isChecked():
            self.uif.notFit.setChecked(False)
            value_list = [gamma_a, gamma_b, gamma_c, fraction_a, fraction_b, fraction_c, g1_from, 
            g1_to, baseline_x_from, baseline_x_to, contrast_x_from, contrast_x_to, baseline_y_from, 
            baseline_y_to, contrast_y_from, contrast_y_to, tau_a_from, tau_a_to, tau_b_from, tau_b_to,
            tau_c_from, tau_c_to, fraction_b_from, fraction_b_to, fraction_c_from, fraction_c_to]
            scan_list_fit[actual_scan] = value_list
        else:
            scan_list_fit[actual_scan] = True


class DLS_Results(QtWidgets.QMainWindow):
    '''
    This class is responsible for the functionality of the result window for the cumulant fits. It sets up the graphs, dropdowns, and checkboxes.
    From here, the fit data can be saved to a result file.
    '''
    def __init__(self):
        super(DLS_Results, self).__init__()
        self.uir = DLS_Results_baseclass.Ui_MainWindow()
        self.uir.setupUi(self)

        self.uir.comboY.addItems(['R\u2095', '\u0393', 'Intensity'])
        self.uir.comboX.addItems(['Scan Number', 'Temperature', 'Time', 'q', 'q\u00B2'])

        self.uir.MplMain = MplResults(self.uir.centralwidget)
        self.uir.MplMain.setObjectName("MplMain")
        self.uir.layoutMain.addWidget(self.uir.MplMain)

        self.uir.Mpl_1 = MplResults(self.uir.centralwidget)
        self.uir.Mpl_1.setObjectName("Mpl_1")
        self.uir.layout1.addWidget(self.uir.Mpl_1)

        self.uir.Mpl_2 = MplResults(self.uir.centralwidget)
        self.uir.Mpl_2.setObjectName("Mpl_2")
        self.uir.layout2.addWidget(self.uir.Mpl_2)

        self.uir.Mpl_3 = MplResults(self.uir.centralwidget)
        self.uir.Mpl_3.setObjectName("Mpl_3")
        self.uir.layout3.addWidget(self.uir.Mpl_3)

        self.uir.comboX.currentTextChanged.connect(self.plot_main)
        self.uir.comboX.currentTextChanged.connect(self.plot_sides)
        self.uir.comboY.currentTextChanged.connect(self.plot_main)
        self.uir.checkXLog.stateChanged.connect(self.plot_main)
        self.uir.checkXLog.stateChanged.connect(self.plot_sides)
        self.uir.checkYLog.stateChanged.connect(self.plot_main)

        self.uir.actionSave_Results.triggered.connect(self.save)

        self.plot_main()
        self.plot_sides()

    def plot_main(self):
        # Sets up the main plot including all labels and limits. There are a few options the user can choose from which result is plotted.

        self.uir.MplMain.canvas.axes.clear()

        if self.uir.comboX.currentText() == 'Scan Number':
            x = scan_list
            self.uir.MplMain.canvas.axes.set_xlabel(r'$Scan$' + ' ' + r'$Number$', fontsize=plot_conc_fontsize_main)
        elif self.uir.comboX.currentText() == 'Temperature':
            x = temp_list
            self.uir.MplMain.canvas.axes.set_xlabel(r'$Temperature$ / °C', fontsize=plot_conc_fontsize_main)
        elif self.uir.comboX.currentText() == 'Time':
            x = time_list
            self.uir.MplMain.canvas.axes.set_xlabel(r'$Time$ / s', fontsize=plot_conc_fontsize_main)
        elif self.uir.comboX.currentText() == 'q':
            x = q_list
            self.uir.MplMain.canvas.axes.set_xlabel(r'$q$ / m' + '\u207B\u00B9', fontsize=plot_conc_fontsize_main)
        elif self.uir.comboX.currentText() == 'q\u00B2':
            x = [i**2 for i in q_list]
            self.uir.MplMain.canvas.axes.set_xlabel(r'$q$' + '\u00B2 / m\u207B\u00B2', fontsize=plot_conc_fontsize_main)

        if self.uir.comboY.currentText() == 'R\u2095':
            plot_list = [Rh_list_1, Rh_list_2, Rh_list_3]
            error_list = [Rh_error_1, Rh_error_2, Rh_error_3]
            color_list = [plot_conc_color1, plot_conc_color2, plot_conc_color3]
            self.uir.MplMain.canvas.axes.set_ylabel(r'$R$' + '\u2095 / nm', fontsize=plot_conc_fontsize_main)
            for i in range(3):
                if len(plot_list[i]) > 0 and not math.isnan(plot_list[i][0]):
                    self.uir.MplMain.canvas.axes.errorbar(x, [num * 1e+09 for num in plot_list[i]], yerr=[num * 1e+09 for num in error_list[i]], label='Particle ' + str(i + 1), color=color_list[i], marker=plot_conc_marker, linestyle=plot_conc_linestyle, markersize=plot_conc_markersize, fillstyle=plot_conc_fillstyle, markeredgewidth=plot_conc_markeredgewidth)
                    self.uir.MplMain.canvas.axes.fill_between(x, [num * 1e+9 for num in (np.array(plot_list[i]) + np.array(error_list[i]))], [num * 1e+9 for num in (np.array(plot_list[i]) - np.array(error_list[i]))], alpha=plot_conc_alpha_R, color=color_list[i])
            self.uir.MplMain.canvas.axes.legend()
        elif self.uir.comboY.currentText() == '\u0393':
            self.uir.MplMain.canvas.axes.set_ylabel('\u0393 / s\u207B\u00B9', fontsize=plot_conc_fontsize_main)
            if fit_type == 'One Decay':
                self.uir.MplMain.canvas.axes.errorbar(x, fit_results[:, 2], yerr=fit_error[:, 2], label='Particle 1', color=plot_conc_color1, marker=plot_conc_marker, linestyle=plot_conc_linestyle, markersize=plot_conc_markersize, fillstyle=plot_conc_fillstyle, markeredgewidth=plot_conc_markeredgewidth)
                self.uir.MplMain.canvas.axes.fill_between(x, fit_results[:, 2] + fit_error[:, 2], fit_results[:, 2] - fit_error[:, 2], alpha=plot_conc_alpha_G, color=plot_conc_color1)
            else:
                if len(Rh_list_1) > 0 and not math.isnan(Rh_list_1[0]):
                    self.uir.MplMain.canvas.axes.errorbar(x, fit_results[:, 3], yerr=fit_error[:, 3], label='Particle 1', color=plot_conc_color1, marker=plot_conc_marker, linestyle=plot_conc_linestyle, markersize=plot_conc_markersize, fillstyle=plot_conc_fillstyle, markeredgewidth=plot_conc_markeredgewidth)
                    self.uir.MplMain.canvas.axes.fill_between(x, fit_results[:, 3] + fit_error[:, 3], fit_results[:, 3] - fit_error[:, 3], alpha=plot_conc_alpha_G, color=plot_conc_color1)
                    if len(Rh_list_2) > 0 and not math.isnan(Rh_list_2[0]):
                        self.uir.MplMain.canvas.axes.errorbar(x, fit_results[:, 7], yerr=fit_error[:, 7], label='Particle 2', color=plot_conc_color2, marker=plot_conc_marker, linestyle=plot_conc_linestyle, markersize=plot_conc_markersize, fillstyle=plot_conc_fillstyle, markeredgewidth=plot_conc_markeredgewidth)
                        self.uir.MplMain.canvas.axes.fill_between(x, fit_results[:, 7] + fit_error[:, 7], fit_results[:, 7] - fit_error[:, 7], alpha=plot_conc_alpha_G, color=plot_conc_color2)
                        if len(Rh_list_3) > 0 and not math.isnan(Rh_list_3[0]):
                            self.uir.MplMain.canvas.axes.errorbar(x, fit_results[:, 11], yerr=fit_error[:, 11], label='Particle 3', color=plot_conc_color3, marker=plot_conc_marker, linestyle=plot_conc_linestyle, markersize=plot_conc_markersize, fillstyle=plot_conc_fillstyle, markeredgewidth=plot_conc_markeredgewidth)
                            self.uir.MplMain.canvas.axes.fill_between(x, fit_results[:, 11] + fit_error[:, 11], fit_results[:, 11] - fit_error[:, 11], alpha=plot_conc_alpha_G, color=plot_conc_color3)
            self.uir.MplMain.canvas.axes.legend()
        elif self.uir.comboY.currentText() == 'Intensity':
            self.uir.MplMain.canvas.axes.set_ylabel(r'$norm. Intensity$', fontsize=plot_conc_fontsize_main)
            self.uir.MplMain.canvas.axes.plot(x, intensity_list, label='norm. Intensity', color=plot_conc_color1, marker=plot_conc_marker, linestyle='--', markersize=plot_conc_markersize, fillstyle=plot_conc_fillstyle, markeredgewidth=plot_conc_markeredgewidth)
            self.uir.MplMain.canvas.axes.legend()

        if self.uir.checkXLog.isChecked():
            self.uir.MplMain.canvas.axes.set_xscale('log')
        if self.uir.checkYLog.isChecked():
            self.uir.MplMain.canvas.axes.set_yscale('log')

        self.uir.MplMain.canvas.draw()
        
    def plot_sides(self):
        # Side plots depicting dispersities, ratios and goodness of the fit. The x-axis is always the same as in the main plot. 
        # The y-axis is not affected by the choices in the dropdown.

        self.uir.Mpl_1.canvas.axes.clear()
        self.uir.Mpl_2.canvas.axes.clear()
        self.uir.Mpl_3.canvas.axes.clear()

        if self.uir.comboX.currentText() == 'Scan Number':
            x = scan_list
            self.uir.Mpl_1.canvas.axes.set_xlabel(r'$Scan$' + ' ' + r'$Number$', fontsize=plot_conc_fontsize_sides)
            self.uir.Mpl_2.canvas.axes.set_xlabel(r'$Scan$' + ' ' + r'$Number$', fontsize=plot_conc_fontsize_sides)
            self.uir.Mpl_3.canvas.axes.set_xlabel(r'$Scan$' + ' ' + r'$Number$', fontsize=plot_conc_fontsize_sides)
        elif self.uir.comboX.currentText() == 'Temperature':
            x = temp_list
            self.uir.Mpl_1.canvas.axes.set_xlabel(r'$Temperature$ / °C', fontsize=plot_conc_fontsize_sides)
            self.uir.Mpl_2.canvas.axes.set_xlabel(r'$Temperature$ / °C', fontsize=plot_conc_fontsize_sides)
            self.uir.Mpl_3.canvas.axes.set_xlabel(r'$Temperature$ / °C', fontsize=plot_conc_fontsize_sides)
        elif self.uir.comboX.currentText() == 'Time':
            x = time_list
            self.uir.Mpl_1.canvas.axes.set_xlabel(r'$Time$ / s', fontsize=plot_conc_fontsize_sides)
            self.uir.Mpl_2.canvas.axes.set_xlabel(r'$Time$ / s', fontsize=plot_conc_fontsize_sides)
            self.uir.Mpl_3.canvas.axes.set_xlabel(r'$Time$ / s', fontsize=plot_conc_fontsize_sides)
        elif self.uir.comboX.currentText() == 'q':
            x = q_list
            self.uir.Mpl_1.canvas.axes.set_xlabel(r'$q$ / m' + '\u207B\u00B9', fontsize=plot_conc_fontsize_sides)
            self.uir.Mpl_2.canvas.axes.set_xlabel(r'$q$ / m' + '\u207B\u00B9', fontsize=plot_conc_fontsize_sides)
            self.uir.Mpl_3.canvas.axes.set_xlabel(r'$q$ / m' + '\u207B\u00B9', fontsize=plot_conc_fontsize_sides)
        elif self.uir.comboX.currentText() == 'q\u00B2':
            x = [i**2 for i in q_list]
            self.uir.Mpl_1.canvas.axes.set_xlabel(r'$q$' + '\u00B2 / m\u207B\u00B2', fontsize=plot_conc_fontsize_sides)
            self.uir.Mpl_2.canvas.axes.set_xlabel(r'$q$' + '\u00B2 / m\u207B\u00B2', fontsize=plot_conc_fontsize_sides)
            self.uir.Mpl_3.canvas.axes.set_xlabel(r'$q$' + '\u00B2 / m\u207B\u00B2', fontsize=plot_conc_fontsize_sides)

        self.uir.Mpl_1.canvas.axes.set_ylabel(r'$Dispersity$', fontsize=plot_conc_fontsize_sides)
        self.uir.Mpl_1.canvas.axes.set_ylim((-0.1, 1))
        self.uir.Mpl_2.canvas.axes.set_ylabel(r'$Ratio$', fontsize=plot_conc_fontsize_sides)
        self.uir.Mpl_3.canvas.axes.set_ylabel(r'$Goodness$' + ' (' + r'$\chi$' + '\u00B2)', fontsize=plot_conc_fontsize_sides)

        plot_list = [pdi_list_1, pdi_list_2, pdi_list_3]
        error_list = [pdi_error_1, pdi_error_2, pdi_error_3]
        color_list = [plot_conc_color1, plot_conc_color2, plot_conc_color3]
        for i in range(3):
            if len(plot_list[i]) > 0 and not math.isnan(plot_list[i][0]):
                self.uir.Mpl_1.canvas.axes.errorbar(x, plot_list[i], label='Particle ' + str(i + 1), yerr=error_list[i], color=color_list[i], marker=plot_conc_marker, linestyle=plot_conc_linestyle, markersize=plot_conc_markersize, fillstyle=plot_conc_fillstyle, markeredgewidth=plot_conc_markeredgewidth)
            self.uir.Mpl_1.canvas.axes.legend()
        plot_list = [ratio_1, ratio_2, ratio_3]
        error_list = [ratio_1_error, ratio_2_error, ratio_3_error]
        for i in range(3):
            if len(plot_list[i]) > 0 and not math.isnan(plot_list[i][0]):
                self.uir.Mpl_2.canvas.axes.errorbar(x, plot_list[i], label='Particle ' + str(i + 1), yerr=error_list[i], color=color_list[i], marker=plot_conc_marker, linestyle=plot_conc_linestyle, markersize=plot_conc_markersize, fillstyle=plot_conc_fillstyle, markeredgewidth=plot_conc_markeredgewidth)
                self.uir.Mpl_2.canvas.axes.fill_between(x, np.array(plot_list[i]) + np.array(error_list[i]), np.array(plot_list[i]) - np.array(error_list[i]), alpha=plot_conc_alpha_R, color=color_list[i])
            self.uir.Mpl_2.canvas.axes.legend()

        self.uir.Mpl_3.canvas.axes.plot(x, chi_square_list, color=plot_conc_color4, marker=plot_conc_marker, linestyle=plot_conc_linestyle, markersize=plot_conc_markersize, fillstyle=plot_conc_fillstyle, markeredgewidth=plot_conc_markeredgewidth)

        if self.uir.checkXLog.isChecked():
            self.uir.Mpl_1.canvas.axes.set_xscale('log')
            self.uir.Mpl_2.canvas.axes.set_xscale('log')
            self.uir.Mpl_3.canvas.axes.set_xscale('log')

        self.uir.Mpl_1.canvas.draw()
        self.uir.Mpl_2.canvas.draw()
        self.uir.Mpl_3.canvas.draw()

    def save(self):
        # The result file is saved here. Options are text files or csv-files at the moment. Everything is saved by default and can not be changed.
        path = QFileDialog.getSaveFileName(self, 'Save Results', default_directory, default_save_filter, options=QFileDialog.DontUseNativeDialog)
        if path[0] != '':
            if path[1][-4:-1] == 'txt':
                delim = '\t'
            elif path[1][-4:-1] == 'csv':
                delim = ','
            with open(path[0] + '.' + path[1][-4:-1], 'w') as f:
                header_names = ['Scan Number', 'Time / s' , 'Temp  / °C', 'q / 1/m', 'Angle / °', 'norm. Intensity', 'Chi^2']
                save_list = [Rh_list_1, Rh_list_2, Rh_list_3]
                for i in range(3):
                    if len(save_list[i]) > 0 and not math.isnan(save_list[i][0]):
                        header_names.append('Gamma ' + str(i + 1) + ' / 1/s')
                        header_names.append('error')
                        header_names.append('Rh ' + str(i + 1) + ' / nm')
                        header_names.append('error')
                        header_names.append('fraction ' + str(i + 1))
                        header_names.append('error')
                        header_names.append('pdi ' + str(i + 1))
                        header_names.append('error')
                header = delim.join(header_names) + '\n'
                f.write(header)

                Rh_list = [Rh_list_1, Rh_list_2, Rh_list_3]
                Rh_error = [Rh_error_1, Rh_error_2, Rh_error_3]
                fraction = [ratio_1, ratio_2, ratio_3]
                fraction_error = [ratio_1_error, ratio_2_error, ratio_3_error]
                pdi = [pdi_list_1, pdi_list_2, pdi_list_3]
                pdi_error = [pdi_error_1, pdi_error_2, pdi_error_3]
                for row in range(len(scan_list)):
                    body = []
                    body.append(str(scan_list[row]))
                    body.append(str(time_list[row]))
                    body.append(str(temp_list[row]))
                    body.append(str(q_list[row]))
                    body.append(str(angle_list[row]))
                    body.append(str(intensity_list[row]))
                    body.append(str(chi_square_list[row]))
                    for i in range(3):
                        if len(save_list[i]) > 0 and not math.isnan(save_list[i][0]):
                            body.append(str(self.append_gamma(row, i)))
                            body.append(str(self.append_gamma_error(row, i)))
                            body.append(str(Rh_list[i][row] * 1e9))
                            body.append(str(Rh_error[i][row] * 1e9))
                            body.append(str(fraction[i][row]))
                            body.append(str(fraction_error[i][row]))
                            body.append(str(pdi[i][row]))
                            body.append(str(pdi_error[i][row]))
                    body_row = delim.join(body) + '\n'
                    f.write(body_row)

    def append_gamma(self, row, i):
        # Depending on the fit function (one, two, or three decays) a different set of parameters needs to be written to the result file.
        if i == 0:
            if fit_type == 'One Decay':
                return fit_results[row][2]
            else:
                return fit_results[row][3]
        elif i == 1:
            return fit_results[row][7]
        elif i == 2:
            return fit_results[row][11]


    def append_gamma_error(self, row, i):
        # Same as for the above function.
        if i == 0:
            if fit_type == 'One Decay':
                return fit_error[row][2]
            else:
                return fit_error[row][3]
        elif i == 1:
            return fit_error[row][7]
        elif i == 2:
            return fit_error[row][11]


class DLS_CONTIN(QtWidgets.QMainWindow):
    '''
    This is the class for the result window after the CONTIN fit. It is based on the DLS_CONTIN_baseclass.
    '''
    def __init__(self):
        super(DLS_CONTIN, self).__init__()
        self.uic = DLS_CONTIN_baseclass.Ui_MainWindow()
        self.uic.setupUi(self)

        self.uic.MplMain = MplResults(self.uic.centralwidget)
        self.uic.MplMain.setObjectName("MplMain")
        self.uic.mplMain.addWidget(self.uic.MplMain)

        self.uic.Mpl_1 = MplResults(self.uic.centralwidget)
        self.uic.Mpl_1.setObjectName("Mpl_1")
        self.uic.mpl_1.addWidget(self.uic.Mpl_1)

        self.uic.Mpl_2 = MplResults(self.uic.centralwidget)
        self.uic.Mpl_2.setObjectName("Mpl_2")
        self.uic.mpl_2.addWidget(self.uic.Mpl_2)

        self.uic.horizontalScrollBar.setMinimum(0)
        self.uic.horizontalScrollBar.setMaximum(len(scan_list) - 1)
        self.uic.horizontalScrollBar.setValue(0)

        self.uic.horizontalScrollBar.valueChanged.connect(self.update_legend)
        self.uic.horizontalScrollBar.valueChanged.connect(self.plot_main)
        self.uic.horizontalScrollBar.valueChanged.connect(self.plot_sides)

        self.uic.actionSave.triggered.connect(self.save)

        self.uic.scanNumber.setText(QtCore.QCoreApplication.translate("MainWindow", str(scan_list[0])))
        self.uic.fileNumber.setText(QtCore.QCoreApplication.translate("MainWindow", str(file_number_list[0])))
        self.uic.temperature.setText(QtCore.QCoreApplication.translate("MainWindow", str(int(temp_list[0] * 100) / 100.0) + ' °C'))
        self.uic.time.setText(QtCore.QCoreApplication.translate("MainWindow", str(time_list[0]) + ' s'))
        self.uic.qLabel.setText(QtCore.QCoreApplication.translate("MainWindow", '{:.2e}'.format(float(q_list[0])) + ' m' + '\u207B\u00B9'))

        self.plot_main()
        self.plot_sides()

    def update_legend(self):
        # Updates the legend on the right side of the result window according to the size distribution depicted.
        i = self.uic.horizontalScrollBar.value()
        self.uic.scanNumber.setText(QtCore.QCoreApplication.translate("MainWindow", str(scan_list[i])))
        self.uic.fileNumber.setText(QtCore.QCoreApplication.translate("MainWindow", str(file_number_list[i])))
        self.uic.temperature.setText(QtCore.QCoreApplication.translate("MainWindow", str(int(temp_list[i] * 100) / 100.0) + ' °C'))
        self.uic.time.setText(QtCore.QCoreApplication.translate("MainWindow", str(time_list[i]) + ' s'))
        self.uic.qLabel.setText(QtCore.QCoreApplication.translate("MainWindow", '{:.2e}'.format(float(q_list[i])) + ' m' + '\u207B\u00B9'))

    def plot_main(self):
        # Plots the data in the main graph which is the unweighted size distributions as calculated from the gamma probabilities.
        self.uic.MplMain.canvas.axes.clear()
        self.uic.MplMain.canvas.axes.set_xlabel(r'$R$' + '\u2095, unweighted / nm', fontsize=plot_c_fontsize_main)
        self.uic.MplMain.canvas.axes.set_ylabel('Relative Abundance', fontsize=plot_c_fontsize_main)
        i = int(self.uic.scanNumber.text())
        self.uic.MplMain.canvas.axes.plot(size_distributions[i * 3], size_distributions[i * 3 + 1], label='none', color=plot_c_color1, marker=plot_c_marker, linestyle=plot_c_linestyle, markersize=plot_c_markersize, fillstyle=plot_c_fillstyle, markeredgewidth=plot_c_markeredgewidth)
        self.uic.MplMain.canvas.axes.fill_between(size_distributions[i * 3], np.array(size_distributions[i * 3 + 1]) + np.array(size_distributions[i * 3 + 2]), np.array(size_distributions[i * 3 + 1]) - np.array(size_distributions[i * 3 + 2]), alpha=plot_c_alpha, color=plot_c_color4)
        self.uic.MplMain.canvas.axes.fill_between(size_distributions[i * 3], size_distributions[i * 3 + 1], 0, alpha=plot_c_alpha, color=plot_c_color1)
        self.uic.MplMain.canvas.axes.set_xscale('log')
        self.uic.MplMain.canvas.axes.set_xlim(plot_c_xlim)
        self.uic.MplMain.canvas.draw()
        
    def plot_sides(self):
        # Plots the data in the side graphs that are the volume weighted and intensity weighted size distributions.
        self.uic.Mpl_1.canvas.axes.clear()
        self.uic.Mpl_2.canvas.axes.clear()
        self.uic.Mpl_1.canvas.axes.set_xlabel(r'$R$' + '\u2095, volume weighted / nm', fontsize=plot_c_fontsize_sides)
        self.uic.Mpl_2.canvas.axes.set_xlabel(r'$R$' + '\u2095, intensity weighted / nm', fontsize=plot_c_fontsize_sides)
        self.uic.Mpl_1.canvas.axes.set_ylabel('Relative Abundance', fontsize=plot_c_fontsize_sides)
        self.uic.Mpl_2.canvas.axes.set_ylabel('Relative Abundance', fontsize=plot_c_fontsize_sides)
        i = int(self.uic.scanNumber.text())
        self.uic.Mpl_1.canvas.axes.plot(size_distributions_volume[i * 3], size_distributions_volume[i * 3 + 1], label='none', color=plot_c_color2, marker=plot_c_marker, linestyle=plot_c_linestyle, markersize=plot_c_markersize, fillstyle=plot_c_fillstyle, markeredgewidth=plot_c_markeredgewidth)
        self.uic.Mpl_2.canvas.axes.plot(size_distributions_intensity[i * 3], size_distributions_intensity[i * 3 + 1], label='none', color=plot_c_color3, marker=plot_c_marker, linestyle=plot_c_linestyle, markersize=plot_c_markersize, fillstyle=plot_c_fillstyle, markeredgewidth=plot_c_markeredgewidth)
        self.uic.Mpl_1.canvas.axes.fill_between(size_distributions_volume[i * 3], np.array(size_distributions_volume[i * 3 + 1]) + np.array(size_distributions_volume[i * 3 + 2]), np.array(size_distributions_volume[i * 3 + 1]) - np.array(size_distributions_volume[i * 3 + 2]), alpha=plot_c_alpha, color=plot_c_color4)
        self.uic.Mpl_1.canvas.axes.fill_between(size_distributions_volume[i * 3], size_distributions_volume[i * 3 + 1], 0, alpha=plot_c_alpha, color=plot_c_color2)
        self.uic.Mpl_2.canvas.axes.fill_between(size_distributions_intensity[i * 3], np.array(size_distributions_intensity[i * 3 + 1]) + np.array(size_distributions_intensity[i * 3 + 2]), np.array(size_distributions_intensity[i * 3 + 1]) - np.array(size_distributions_intensity[i * 3 + 2]), alpha=plot_c_alpha, color=plot_c_color4)
        self.uic.Mpl_2.canvas.axes.fill_between(size_distributions_intensity[i * 3], size_distributions_intensity[i * 3 + 1], 0, alpha=plot_c_alpha, color=plot_c_color3)
        self.uic.Mpl_1.canvas.axes.set_xscale('log')
        self.uic.Mpl_2.canvas.axes.set_xscale('log')
        self.uic.Mpl_1.canvas.axes.set_xlim(plot_c_xlim)
        self.uic.Mpl_2.canvas.axes.set_xlim(plot_c_xlim)
        self.uic.Mpl_1.canvas.draw()
        self.uic.Mpl_2.canvas.draw()

    def save(self):
        # Initializes the save menu for the CONTIN fit. After changing the path, a popup opens where the user can choose which size distribution is saved.
        path = QFileDialog.getSaveFileName(self, 'Save Results', default_directory, default_save_filter, options=QFileDialog.DontUseNativeDialog)
        if path[0] == '':
            return
        box = QMessageBox()
        box.setIcon(QMessageBox.Question)
        box.setWindowTitle('Saving...')
        box.setText("Which size distribution do you want to save?")
        box.setStandardButtons(QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel | QMessageBox.YesToAll)
        button1 = box.button(QMessageBox.Yes)
        button1.setText('Unweighted')
        button2 = box.button(QMessageBox.No)
        button2.setText('Intensity Weighted')
        button3 = box.button(QMessageBox.Cancel)
        button3.setText('All')
        button4 = box.button(QMessageBox.YesToAll)
        button4.setText('Volume Weighted')
        box.exec_()

        if box.clickedButton() == button1:
            self.writing(path, 'unweighted')
        elif box.clickedButton() == button4:
            self.writing(path, 'volume_weighted')
        elif box.clickedButton() == button2:
            self.writing(path, 'intensity_weighted')
        elif box.clickedButton() == button3:
            self.writing(path, 'unweighted')
            self.writing(path, 'volume_weighted')
            self.writing(path, 'intensity_weighted')

    def writing(self, path, distr):
        # This function actually saves the data.
        if path[0] != '':
            if path[1][-4:-1] == 'txt':
                delim = '\t'
            elif path[1][-4:-1] == 'csv':
                delim = ','
            with open(path[0] + '_' + distr + '.' + path[1][-4:-1], 'w') as f:
                header_names = []
                for i in file_number_list:
                    header_names.append('Rh / nm')
                    header_names.append('#' + str(i))
                    header_names.append('#' + str(i) + ' error')
                header = delim.join(header_names) + '\n'
                f.write(header)

                for row in range(len(size_distributions[0])):
                    body = []
                    for i in range(len(scan_list)):
                        if distr == 'unweighted':
                            body.append(str(size_distributions[i * 3][row]))
                            body.append(self.write_unweighted(row, i * 3 + 1))
                            body.append(self.write_unweighted(row, i * 3 + 2))
                        elif distr == 'volume_weighted':
                            body.append(str(size_distributions[i * 3][row]))
                            body.append(self.write_volume_weighted(row, i * 3 + 1))
                            body.append(self.write_volume_weighted(row, i * 3 + 2))
                        elif distr == 'intensity_weighted':
                            body.append(str(size_distributions[i * 3][row]))
                            body.append(self.write_intensity_weighted(row, i * 3 + 1))
                            body.append(self.write_intensity_weighted(row, i * 3 + 2))
                    body_row = delim.join(body) + '\n'
                    f.write(body_row)

    def write_unweighted(self, row, col):
        return str(size_distributions[col][row])

    def write_volume_weighted(self, row, col):
        return str(size_distributions_volume[col][row])

    def write_intensity_weighted(self, row, col):
        return str(size_distributions_intensity[col][row])




progress_counter = 0
scan_list = []
file_number_list = []
time_list = []
temp_list = []
wavelength_value = []
angle_list = []
refractive_list = []
visc_list = []
correlation_x_list = []
correlation_y_list = []
corr_error_list = []

fit_parameters = [0 for i in range(26)]

scan_list_fit = [True]
actual_scan = 0

fit_results = []
fit_error = []

q_list = []
intensity_list = []
Rh_list_1 = []
Rh_list_2 = []
Rh_list_3 = []
Rh_error_1 = []
Rh_error_2 = []
Rh_error_3 = []
pdi_list_1 = []
pdi_list_2 = []
pdi_list_3 = []
pdi_error_1 = []
pdi_error_2 = []
pdi_error_3 = []
ratio_1 = []
ratio_2 = []
ratio_3 = []
ratio_1_error = []
ratio_2_error = []
ratio_3_error = []
chi_square_list = []
param_error = []

size_distributions = []
size_distributions_volume = []
size_distributions_intensity = []
    
dragged_rect = 'none'

initialization_visible = False
result_visible = False


if __name__ == "__main__":
     app = QtWidgets.QApplication(sys.argv)
     window = DLS_Main()
     window.show()
     sys.exit(app.exec_())