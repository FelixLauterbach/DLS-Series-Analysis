import numpy as np
import matplotlib.pyplot as plt
from matplotlib import style

style.use('dark_background')
plt.figure(figsize=(5,5))


# correlation functions
# x1 = np.logspace(-8, 5, 100)
# y1 = np.exp(-500000*x1)
# y2 = np.exp(-500*x1)
# y3 = np.exp(-0.5*x1)
# y4 = np.exp(-0.0005*x1)

# plt.plot(x1,y1, color='deepskyblue', linewidth=25, alpha=1)
# plt.plot(x1,y2, color='firebrick', linewidth=25, alpha=1)
# plt.plot(x1,y3, color='forestgreen', linewidth=25, alpha=1)
# plt.plot(x1,y4, color='darkorange', linewidth=25, alpha=1)
# plt.xscale('log')



# size distributions
# x1 = np.linspace(0, 200, 40)

# def gauss(x, mean, sigma):
# 	return 1 / np.sqrt(2*np.pi*sigma**2) * np.exp(-(x-mean)**2/(2*sigma**2))

# y1 = gauss(x1, 40, 20)
# y2 = gauss(x1, 120, 35)

# plt.bar(x1,y1, width=6, color='forestgreen', linewidth=12, alpha=1)
# plt.bar(x1,y2, width=6, color='darkorange', linewidth=12, alpha=1)



# results
# x1 = np.linspace(-15, 15, 100)
# y1 = 1 / (1 + np.exp(-0.4*(x1-5)))
# y2 = 1 / (1 + np.exp(-0.4*(x1+5)))

# plt.plot(x1,y1, color='deepskyblue', linewidth=25, alpha=1)
# plt.plot(x1,y2, color='darkorange', linewidth=25, alpha=1)



# initialization
# parameters = ('Param 1', 'Param 2', 'Param 3', 'Param 4', 'Param 5')
# y_pos = np.arange(len(parameters))
# value = [7, 3, 5, 4, 6]
# plt.barh(y_pos, value)


plt.show()